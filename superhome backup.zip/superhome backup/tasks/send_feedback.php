<div class="content">
		<div class="container-flud">
			<div class="row">	
				<div class="col-sm-12 m-auto">
					<div class="card card-info" style="white-space: normal;">
						<div class="card-header">
							<h3 class="card-title">Task Review & Confirmation</h3>
						</div>
						<div class="card mb-3">
							<?php if($task_info->task_image): ?>
								<img src='<?= base_url()?>assets/uploads/task_list/<?=$task_info->task_image?>' class='card-img-top' style='max-height: 400px'>
							<?php endif; ?>

							<div class="card-body">
								<h3 class="my-3"><?=$task_info->title?></h3>
								<p class="card-text"><?=$task_info->description?></p>
								<p class="card-text"><small class="text-muted"><?=$task_info->created_at?></small></p>
							</div>
						</div>
                                
                        <div style="overflow-y:auto;">
                            <div class="mx-2">
                                <?php foreach ($task_review as $key => $value) { 
                                    $files = explode(',',$value->task_files);
                                    ?>
                                    <h5><i class="fas fa-user-circle"></i> <?=$value->emp_name?></h5>
                                        
                                    <div class="ml-4">
                                        <div><?=$value->feedback?></div>
                                        <?php foreach ($files as  $file) {
                                            if (!empty($file)) {
                                                echo '<a href="'.base_url($file).'" target="_blank"><img src="'.base_url($file).'" class="img-thumbnail" width="100px;"></a>';
                                            }
                                        }?>
                                    </div>
                                    <?php } ?>
                            </div>
                            <form action="" method="post" id="review_form_<?=$task_info->id?>" class="m-4">
                                <input type="hidden" name="review_submit">
                                <input type="hidden" name="task_id" value="<?=$task_info->id?>">
                                <div class="mb-3">
                                    <label for="validationTextarea">Feedback</label>
                                    <textarea class="form-control" id="validationTextarea" name="description" placeholder="Description, what you do?" required></textarea>
                                </div>

                                <div class="custom-file">
                                <input type="file" class="custom-file-input" id="customFile" name="review_files[]" multiple>
                                <label class="custom-file-label" for="customFile">Choose file</label>
                                </div>
                                <div class="text-right mt-3">
                                    <button type="submit" class="btn btn-xs btn-primary">Send Feedback</button>
                                </div>
                            </form>
                        </div>   
                        <div class="border-top mb-3">
                            <form action="<?=base_url('admin/s_it/tasks'); ?>" method="post" id="complete_task_form_<?=$task_info->id?>">
                                <input type="hidden" name="task_id" value="<?=$task_info->id ?>">
                                <input type="hidden" name="emp_id" value="<?=$task_info->processing_by?>">
                                <?php if (isset($task_point_info)) { 
                                    if ($task_point_info->task_type=='regular'){
                                        $max='max="100"';
                                        $min='min="5"';
                                        $placeholder = 'placeholder="Point 5% to 30%"';
                                   }else{
                                       $max='';
                                       $min='0';
                                       $placeholder='';
                                   }
                                ?>
                                <div class="form-group row m-3">
                                    <label for="inputPassword" class="col-sm-4 col-form-label">Task Point (<?=ucwords($task_point_info->task_type)?>):</label>
                                    <div class="col-sm-8">
                                        <input type="number" step="any" class="form-control" <?=$placeholder?> <?=$min?> <?=$max?> name="task_point" value="<?=$task_point_info->task_point?>">
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-xs btn-danger">Confirm Task</button>
                                </div>
                            </form>
                        </div>
					</div>
				</div>				
			</div>
		</div>
	</div>
</div>
<script>
    $("#review_form_<?=$task_info->id?>").on('submit',function (e) {
        e.preventDefault();
        
        $.ajax({
            url: "<?php echo base_url("admin/s_it/tasks"); ?>",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            beforeSend:function(){					
                $('#data-loading').html(data_loading);					 
            },
            success: function(result)
            { 
                $('#data-loading').html('');	
                if (result=='success') {
                    swal.fire({
						title: "Success!",
						text: "Data created !",
						icon: "success",
						button: "Ok",
					});
                }
                $('#exampleModal').modal('hide');
                // window.location.reload();
            },
            error: function() 
            {
                // window.location.reload();
            } 	        
        });
    })

    $("#complete_task_form_<?=$task_info->id?>").on('submit',function (e) {
        e.preventDefault();
        if (!confirm("Are you sure about action!")) {
            return false;
        }
        $.ajax({
            url: "<?php echo base_url("admin/s_it/complete_task"); ?>",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            beforeSend:function(){					
                $('#data-loading').html(data_loading);					 
            },
            success: function(data)
            { 
                $('#data-loading').html('');	
            	$('#pending_data_table,#processing_data_table,#review_data_table,#complete_data_table').DataTable().ajax.reload( null , false);
				// $(".complete_body").html(new_data['html']);	
                if (result=='success') {
                    swal.fire({
						title: "Success!",
						text: "Data created !",
						icon: "success",
						button: "Ok",
					});
                }
                $('#exampleModal').modal('hide');
                // window.location.reload();
            },
            error: function() 
            {
                // window.location.reload();
            } 	        
        });
    })
</script>
<?php foreach($task_complete as $key=>$task): ?>
	<tr data-row="<?php echo $task->id; ?>">
			<td><?php echo $task->id; ?></td>
			<td class="text-truncate" style="max-width: 150px;"><?php echo $task->title; ?></td>
			<td><?php echo $task->emp_name_by; ?></td>
			<td><?php echo $task->emp_name_com; ?></td>
			<?php
			$phpdate = strtotime( $task->completed_at );
			$mysqldate = date( 'd M Y', $phpdate );
		?>
			<td><?php echo $mysqldate ?></td>
			
		<td class="d-flex">
			<!-- Button trigger modal for veiw -->
			<a href="#" data-task_info="<?php echo $task->id; ?>" class="btn btn-xs btn-warning task_veiw" ><i class="fa fa-eye"></i></a>
		</td>
	</tr>
<?php endforeach; ?>
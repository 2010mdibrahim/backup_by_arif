<?php foreach($task_processing as $key=>$task): ?>
    <tr data-row="<?php echo $task->id; ?>">
            <td><?php echo $task->id; ?></td>
            <td class="text-truncate" style="max-width: 150px;"><?php echo $task->title; ?></td>
            <td><?php echo $task->emp_name_by; ?></td>
            <td><?php echo $task->emp_name_pro; ?></td>
            <td class="demo" data-val="<?php echo $task->target_at ?>"></td>
        <td class="d-flex">

            
            <!-- Button trigger modal for veiw -->
            <a href="#" data-task_info="<?php echo $task->id; ?>" class="btn btn-xs btn-warning task_veiw" ><i class="fa fa-eye"></i></a>
			<!-- send for review -->
			<?php if (isset($task->assigned_by) && $task->assigned_by != $task->processing_by && $task->processing_by==$_SESSION['super_admin']['employee_ids']) {  ?>
				<button class="btn btn-xs btn-info ml-1" onclick="reviewModal(<?php echo $task->id; ?>)" title="Send for review"><i class="fas fa-file-export"></i></button>
			<?php } ?>
        </td>
    </tr>
<?php endforeach; ?> 


<script>
    $(".demo").each(function(index){
		var obj=$(this);
		var countDownDate=new Date(obj.data('val')).getTime();
		var x=setInterval(function(obj,countDownDate){
			var now=new Date().getTime();
			var distance=countDownDate-now;
			// If the count down is over 
			if (distance<0){
				// clearInterval(x);
				// obj.text("EXPIRED");
				
				// Time calculations for days, hours, minutes and seconds
				var dist=now-countDownDate;
				var days = Math.floor(dist / (1000 * 60 * 60 * 24));
				var hours = Math.floor((dist % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
				var minutes = Math.floor((dist % (1000 * 60 * 60)) / (1000 * 60));
				var seconds = Math.floor((dist % (1000 * 60)) / 1000);
				obj.text('-'+days+"d "+hours+"h "+minutes+"m "+seconds+"s ");
			}else{
				// Time calculations for days, hours, minutes and seconds
				var days = Math.floor(distance / (1000 * 60 * 60 * 24));
				var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
				var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
				var seconds = Math.floor((distance % (1000 * 60)) / 1000);
				obj.text(days+"d "+hours+"h "+minutes+"m "+seconds+"s ");
			}
		}, 1000,obj,countDownDate);
	});
</script>
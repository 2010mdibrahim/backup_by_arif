<div class="content-wrapper">
	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-3">
					<h1 class="m-0 text-dark d-inline-flex mr-2">Daily Point Approval</h1>
					<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
						Add Task 
						<i class="fas fa-plus"></i>
					</button> -->
				</div> 
				<div class="col-sm-6">
				</div> 
				<div class="col-sm-3">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=base_url();?>">Home</a></li>
						<li class="breadcrumb-item"><a href="#">Tasks</a></li>
						<li class="breadcrumb-item active">Task/Performance</li>
					</ol>
				</div> 
			</div> 
		</div> 
    </div>
	

	<div class="content">
		<div class="container-flud">
			<div class="mx-4">
				<div class="row flex-row flex-nowrap">
					<!-- table 3 -->
					<div class="col-sm-12">
						<div class="card card-success">
							<div class="card-header">
								<h3 class="card-title">Task/Performance List</h3>
								<div id="export_button_com" class="float-right"></div>
							</div>
							<div class="card-body">
								<div class="card card-primary card-outline card-outline-tabs">
									<div class="card-header p-0 border-bottom-0">
										<ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
											<li class="nav-item">
												<a class="nav-link active" id="custom-tabs-four-home-tab" data-toggle="pill" href="#custom-tabs-four-home" role="tab" aria-controls="custom-tabs-four-home" aria-selected="true">Pending</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" id="custom-tabs-four-profile-tab" data-toggle="pill" href="#custom-tabs-four-profile" role="tab" aria-controls="custom-tabs-four-profile" aria-selected="false">Approved</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" id="custom-tabs-four-messages-tab" data-toggle="pill" href="#custom-tabs-four-messages" role="tab" aria-controls="custom-tabs-four-messages" aria-selected="false">Rejected</a>
											</li>										
										</ul>
									</div>
									<div class="card-body">
										<div class="tab-content" id="custom-tabs-four-tabContent">
											<div class="tab-pane fade active show" id="custom-tabs-four-home" role="tabpanel" aria-labelledby="custom-tabs-four-home-tab">
												<div class="export_buttons"></div>
													<table class="table table-striped table-bordered table-sm small" id="pending_data_table" style="white-space: nowrap;width:100%;">
														<thead>
															<tr>
																<th>ID</th>
																<th>Picture</th>
																<th>Completed By</th>
																<th>Department</th>
																<th style="max-width: 800px;">Title</th>
																<th>Task Point</th>
																<th>D-Head Point (If want)</th>
																<th>Assigned By</th>
																<th>Completed At</th>
																<?php if($_SESSION['super_admin']['user_type'] == 'Super Admin'): ?>
																<th>Action</th>
																<?php endif; ?>
															</tr>
														</thead>
														<tbody></tbody>
															
													</table>
												</div>
												<div class="tab-pane fade" id="custom-tabs-four-profile" role="tabpanel" aria-labelledby="custom-tabs-four-profile-tab">
													<div class="export_buttons_1"></div>
													<table class="table table-striped table-bordered table-sm small" id="approved_data_table" style="white-space: nowrap;width:100%;">
														<thead>
															<tr>
																<th>ID</th>
																<th>Picture</th>
																<th>Completed By</th>
																<th>Department</th>
																<th style="max-width: 800px;">Title</th>
																<th>Task Point</th>
																<th>D-Head Point (If want)</th>
																<th>Assigned By</th>
																<th>Completed At</th>
															</tr>
														</thead>
														<tbody></tbody>
															
													</table>
												</div>
												<div class="tab-pane fade" id="custom-tabs-four-messages" role="tabpanel" aria-labelledby="custom-tabs-four-messages-tab">
													<div class="export_buttons_2"></div>
														<table class="table table-striped table-bordered table-sm small" id="rejected_data_table" style="white-space: nowrap;width:100%;">
															<thead>
																<tr>
																	<th>ID</th>
																	<th>Picture</th>
																	<th>Completed By</th>
																	<th>Department</th>
																	<th style="max-width: 800px;">Title</th>
																	<th>Task Point</th>
																	<th>D-Head Point (If want)</th>
																	<th>Assigned By</th>
																	<th>Completed At</th>
																</tr>
															</thead>
															<tbody></tbody>
																
														</table>
													</div>										
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>				
			</div>
		</div>
	</div>
</div>

<!-- Veiw Modal -->
<div class="modal fade processing_modal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Task Info</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="task_item">
        ...
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<?php 
$department ='';
foreach ($department_info as $key => $depart) {
    $department .= '<option value="'.$depart->department_id.'">'.$depart->department_name.'</option>';
  }

$employees ='';
foreach ($employee_info as $key => $employ) {
    $employees .= '<option value="'.$employ->employee_id.'">'.$employ->full_name.'</option>';
  }
?>

<script>
    $(document).ready(function(){
        var filter = '';
		filter += '<select class="department_filter custom-select-sm form-control form-control-sm select22" style="max-width: 33.3%;" onchange="taskFilter(this,\'department\',\'complete\')">';
		filter += '<option value="">Filter by Department</option>';
		filter += '<?=$department?>';
		filter += '</select>';
  				
		filter += '';
		filter += '<select class="custom-select-sm form-control form-control-sm select22" style="max-width: 33.3%;" onchange="taskFilter(this,\'employee\',\'complete\')">';
		filter += '<option value="">Filter by Employee</option>';
		filter += '<?=$employees?>';
		filter += '</select>';

		filter+=`<input type="text" class="datepicker department_filter custom-select-sm  form-control-sm" id="datepicker" placeholder="Filter by Date" name="month_year" style="width: 33.3%;border: 1px solid #ced4da;" onchange="taskFilter(this,\'date\',\'complete\')" autocomplete="off">`;
		

		<?php if($_SESSION['super_admin']['user_type'] == 'Super Admin'): ?>
			setTimeout(() => {
				add_filter = `<div class="d-flex justify-content-between">${filter}</div>`;
				$('#pending_data_table_wrapper').prepend(add_filter);
				// $('.select2').select2();
			}, 800);
		<?php endif; ?>

        pending = $('#pending_data_table').DataTable({
			"paging": true,
			"language": {  "infoFiltered": "" },
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"order": [[ 0, "desc" ]],				
			"processing": false,
			"serverSide": true,   
			"ajax"	: {
				url			: "<?=current_url(); ?>",
				data    	: {"complete-data-table":'active', "approval_status":'pending'},
				type		: 'POST',
				beforeSend	: function(){  },
				complete	: function(){ 

				}			
			},     
			"dom": 'lBfrtip',
			"buttons": [			
			{
				extend: 'copy',
				text: '<i class="fas fa-copy"></i>',
				titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'csv',
				text: '<i class="fas fa-file-csv"></i>',
				titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
				text: '<i class="fas fa-file-pdf"></i>',
				titleAttr: 'PDF'
			}, 
			{
				extend: 'print',
				text: '<i class="fas fa-print"></i>',
				titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'colvis',
				text: '<i class="fas fa-list"></i>',
				titleAttr: 'Column Visibility'
			}
		],

		});
		pending.buttons().container().appendTo($('#export_button_com'));

		// **************** approved data table ******************
		approved = $('#approved_data_table').DataTable({
			"paging": true,
			"language": {  "infoFiltered": "" },
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"order": [[ 0, "desc" ]],				
			"processing": false,
			"serverSide": true,   
			"ajax"	: {
				url			: "<?=current_url(); ?>",
				data    	: {"complete-data-table":'active', "approval_status":'approved'},
				type		: 'POST',
				beforeSend	: function(){  },
				complete	: function(){ 

				}			
			},     
			"dom": 'lBfrtip',
			"buttons": [			
			{
				extend: 'copy',
				text: '<i class="fas fa-copy"></i>',
				titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'csv',
				text: '<i class="fas fa-file-csv"></i>',
				titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
				text: '<i class="fas fa-file-pdf"></i>',
				titleAttr: 'PDF'
			}, 
			{
				extend: 'print',
				text: '<i class="fas fa-print"></i>',
				titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'colvis',
				text: '<i class="fas fa-list"></i>',
				titleAttr: 'Column Visibility'
			}
		],

		});
		// approved.buttons().container().appendTo($('.export_buttons_1'));

		// **************** rejected data table ******************
		rejected = $('#rejected_data_table').DataTable({
			"paging": true,
			"language": {  "infoFiltered": "" },
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"order": [[ 0, "desc" ]],				
			"processing": false,
			"serverSide": true,   
			"ajax"	: {
				url			: "<?=current_url(); ?>",
				data    	: {"complete-data-table":'active', "approval_status":'rejected'},
				type		: 'POST',
				beforeSend	: function(){  },
				complete	: function(){ 

				}			
			},     
			"dom": 'lBfrtip',
			"buttons": [			
			{
				extend: 'copy',
				text: '<i class="fas fa-copy"></i>',
				titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'csv',
				text: '<i class="fas fa-file-csv"></i>',
				titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
				text: '<i class="fas fa-file-pdf"></i>',
				titleAttr: 'PDF'
			}, 
			{
				extend: 'print',
				text: '<i class="fas fa-print"></i>',
				titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'colvis',
				text: '<i class="fas fa-list"></i>',
				titleAttr: 'Column Visibility'
			}
		],

		});
		// rejected.buttons().container().appendTo($('.export_buttons_2'));

        //  view page with modal
        $(document).on('click', ".task_veiw", function(e){
            e.preventDefault(); 
            var task_info = $(this).data("task_info");
            $.ajax({
                url: "<?php echo base_url("admin/s_it/task-detail"); ?>",
                method: "POST",
                dataType: "HTML",
                data: {task_info : task_info},
                success: function(data){
                    $(".processing_modal").modal('show');
                    $("#task_item").html(data);
                }
                
            })
        });
    })

    setTimeout(() => {
		$( function() {
			$( ".datepicker" ).datepicker({
				format: "yyyy-mm",
				startView: "months", 
				minViewMode: "months"
			});
		});
	
	}, 3000);
    
    function taskFilter(thes,type,taskType){
		var department = '';
		var date = '';
		var employee = '';
		if (type == 'department') {
			department = thes.value
		}else if(type == 'date'){
			date = thes.value
		}else if(type == 'employee'){
			employee = thes.value
		}
		if (thes.value.trim() != '') {
			if(taskType == 'complete'){
				var ajax_data = "<?=base_url('admin/s_it/task-point-approval')?>?complete-data-table=active&departments="+department+"&employee="+employee+"&date="+date;
				$('#pending_data_table').DataTable().ajax.url(ajax_data).load();
			}
		}
	}

    function pointForm(taskId) {
		$.ajax({
			url: "<?php echo base_url("admin/s_it/task-detail"); ?>",
			method: "POST",
			dataType: "HTML",
			data: {task_info : taskId, get_point_form:'yes'},
			success: function(data){
				$(".processing_modal").modal('show');
				$("#task_item").html(data);
			}
			
		})
	}

	setTimeout(() => {
		$(function () {
			$('[data-toggle="tooltip"]').tooltip();
		})
	}, 1500);

	const copyToClipboard = async (text,these) => {
		try {
			var $temp = $("<input>");
			$("body").append($temp);
			$temp.val(text).select();
			document.execCommand("copy");
			// $temp.remove();
			// await navigator.clipboard.writeText(text);
			$(these).attr("data-original-title", "Copied: "+text).tooltip('show');
			$(these).attr("data-original-title", text);
		} catch (err) {
			console.error('Failed to copy: ', err);
		}
	}

	function task_point_approval(id) {
		var task_point = $("#task_point_"+id).val();
		var assignee_point = $("#assignee_point_"+id).val();
		var total_point = $("#total_point_"+id).val();
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, Approve it!'
		}).then((result) => {
			if (result.isConfirmed && task_point.trim() != '') {
				$.ajax({
					url: "<?=base_url(); ?>/admin/s_it/task-detail",
					type: "POST",
					async: true,
					data: {approve_task_point:'yes',total_point, task_id:id, task_point,assignee_point},
					success: function(res) {
						if (res='success') {
							$("#task_point_form").trigger("reset"); // to reset form input fields
							$(".processing_modal").modal('hide');
							$("#point_button_"+id).remove();
							$("#reject_button_"+id).remove();

							Swal.fire(
							'Success!',
							'Bonus point approved successfully.',
							'success'
							)
						}
						$('#pending_data_table').DataTable().ajax.url('').load();
					},
					error: function(e) {
						console.log(e);
					}
				});
			}
		});
	}

	function task_point_reject(id) {
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, Reject it!'
		}).then((result) => {
			if (result.isConfirmed) {
				$.ajax({
					url: "<?=base_url(); ?>/admin/s_it/task-detail",
					type: "POST",
					async: true,
					data: {reject_task_point:'yes', task_id:id,},
					success: function(res) {
						if (res='success') {
							$("#task_point_form").trigger("reset"); // to reset form input fields
							$(".processing_modal").modal('hide');
							$("#point_button_"+id).remove();
							$("#reject_button_"+id).remove();

							Swal.fire(
							'Success!',
							'Successfully rejected.',
							'success'
							)
						}
						$('#pending_data_table').DataTable().ajax.url('').load();
					},
					error: function(e) {
						console.log(e);
					}
				});
			}
		});
	}

	$(document).ready(function() {
		$("#task_point_approval").on('submit', (function(e) {
			e.preventDefault();
		}));
	});

	function bonus_calc(these,id,type) {
		var percentage_of_bonus = parseFloat($(these).val());
		if (type=='head') {
			var sallary_per_day = parseFloat($("#sallary_per_day_"+type+"_"+id).val());
			var bouns = (sallary_per_day * percentage_of_bonus) / 100;
			$("#performance_bonus_"+type+"_"+id).text('BDT '+ numRound(bouns,2));
		}else{
			var sallary_per_day = parseFloat($("#sallary_per_day_"+id).val());
			var bouns = (sallary_per_day * percentage_of_bonus) / 100;
			$("#performance_bonus_"+id).text('BDT '+ numRound(bouns,2));
		}
	}

</script>
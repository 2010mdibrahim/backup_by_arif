
<link rel="stylesheet" type="text/css" href="<?=base_url('assets/plugins/toastr/toastr.min.css');?>">
<script src="<?=base_url('assets/plugins/toastr/toastr.min.js');?>"> </script>
<link href="<?=base_url('assets/plugins/datatables_scroller/datatables.min.css')?>" rel="stylesheet"/>
<style>
	.my-custom-scrollbar { position: relative; max-height: 70vh; overflow: auto; }
	.table-wrapper-scroll-y { display: block; }
	.rate { float: right; height: 46px;  padding: 0 10px; }
	.rate:not(:checked) > input { position:absolute; top:-9999px; }
	.rate:not(:checked) > label { float:right; width:1em; overflow:hidden; white-space:nowrap; cursor:pointer; font-size:30px; color:#ccc; }
	.rate:not(:checked) > label:before { content: '★ '; }
	.rate > input:checked ~ label { color: #ffc700;  }
	.rate:not(:checked) > label:hover,
	.rate:not(:checked) > label:hover ~ label { color: #deb217;  }
	.rate > input:checked + label:hover,
	.rate > input:checked + label:hover ~ label,
	.rate > input:checked ~ label:hover,
	.rate > input:checked ~ label:hover ~ label,
	.rate > label:hover ~ input:checked ~ label { color: #c59b08; }
	.checked { color: orange; }

	/* image preview frame */
	
	.imgFrame {
		/* max-width: 200px; */
		margin-top: 30px;
		height: 200px;
		padding: 10px;
		display: flex;
		align-items: center;
		justify-content: center;
		text-align: center;
		font-family: "Quicksand", sans-serif;
		font-weight: 500;
		font-size: 20px;
		cursor: pointer;
		color: #cccccc;
		border: 4px groove #009578;
		border-radius: 10px;
	}
	
	/* select2 */
	.select2-container{
        width: 180px !important;
    }
    .select2-container .select2-selection--single {
        height: 32px !important;
        padding-top: 10px;
    }
    .select2-selection__arrow {
        top: -3px !important;
    }
    .select2-selection__rendered {
        line-height: 20px!important;
    }
    .select2-container {
        display: inline-block;
    }

	#myform .select2-container{
        width: 100% !important;
	}
	/* image upload css */
	.drop-zone {
		/* max-width: 200px; */
		height: 200px;
		padding: 25px;
		display: flex;
		align-items: center;
		justify-content: center;
		text-align: center;
		font-family: "Quicksand", sans-serif;
		font-weight: 500;
		font-size: 20px;
		cursor: pointer;
		color: #cccccc;
		border: 4px dashed #009578;
		border-radius: 10px;
	}
	.drop-zone--over {
		border-style: solid;
	}

	.drop-zone__input {
		display: none;
	}

	.drop-zone__thumb {
		width: 100%;
		height: 100%;
		border-radius: 10px;
		overflow: hidden;
		background-color: #cccccc;
		background-size: cover;
		position: relative;
	}

	.drop-zone__thumb::after {
		content: attr(data-label);
		position: absolute;
		bottom: 0;
		left: 0;
		width: 100%;
		padding: 5px 0;
		color: #ffffff;
		background: rgba(0, 0, 0, 0.75);
		font-size: 14px;
		text-align: center;
	}
	.table td, .table th{
		border-top: 0;
	}

	table.dataTable thead > tr > th.sorting::before, table.dataTable thead > tr > th.sorting::after, table.dataTable thead > tr > th.sorting_asc::before, table.dataTable thead > tr > th.sorting_asc::after, table.dataTable thead > tr > th.sorting_desc::before, table.dataTable thead > tr > th.sorting_desc::after, table.dataTable thead > tr > th.sorting_asc_disabled::before, table.dataTable thead > tr > th.sorting_asc_disabled::after {
		line-height: 30px;
	}
	/* for complete task */
	.container {
		clear: both;
		position: relative;
	}
	.container .arrow {
		width: 12px;
		height: 20px;
		overflow: hidden;
		position: relative;
		float: left;
		top: 6px;
		right: -1px;
	}
	.container .arrow .outer {
		width: 0;
		height: 0;
		border-right: 20px solid #000000;
		border-top: 10px solid transparent;
		border-bottom: 10px solid transparent;
		position: absolute;
		top: 0;
		left: 0;
	}
	.container .arrow .inner {
		width: 0;
		height: 0;
		border-right: 20px solid #ffffff;
		border-top: 10px solid transparent;
		border-bottom: 10px solid transparent;
		position: absolute;
		top: 0;
		left: 2px;
	}
	.container .message-body {
		float: left;
		width: 95%;
		height: auto;
		border: 1px solid #CCC;
		background-color: #ffffff;
		border: 1px solid #000000;
		padding: 6px 8px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		-o-border-radius: 5px;
		border-radius: 5px;
	}
	.container .message-body p {
		margin: 0;
	}
</style>
<?php $colVal = $_SESSION['user_info']['d_head']=='1'? 3 : 4; ?>
<div class="content-wrapper">
	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-3">
					<h1 class="m-0 text-dark d-inline-flex mr-2">Performance</h1>
					<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
						Add Task 
						<i class="fas fa-plus"></i>
					</button> -->
				</div> 
				<div class="col-sm-6">
					<center>
						<h1>For Best performance, Assign Task!</h1>
					</center>
				</div> 
				<div class="col-sm-3">
					<ol class="breadcrumb float-sm-right">
						<li>
							<button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target="#staticBackdrop">
								Add Performance
								<i class="fas fa-plus"></i>
							</button>
						</li>
						<li class="breadcrumb-item"><a href="<?=base_url();?>">Home</a></li>
						<!-- <li class="breadcrumb-item"><a href="#">Task</a></li> -->
						<li class="breadcrumb-item active">Performance</li>
					</ol>
				</div> 
			</div> 
		</div> 
    </div>
	

	<div class="content">
		<div class="container-flud">
			<div style="">
				<div class="row flex-row flex-nowrap">
				<!-- table 1 -->

					<div class="col-sm-<?=$colVal?>">
						<div class="card card-warning">
							<div class="card-header">
								<h3 class="card-title">Performance list (Queue)</h3>
								<div id="export_buttonscc" class="float-right"></div>
							</div>
							<div class="card-body">
							<!-- table table-striped table-bordered table-sm small -->
								<table class="table  table-hover table-sm small queue" id="pending_data_table" style="white-space: nowrap;">
									<thead>
										<tr>
											<th>ID</th>
											<!-- <th>Title</th>
											<th>Assigned By</th>
											<th>Assigned To</th>
											<th>Priority</th>
											<th>Deadline</th>
											<th>Action</th> -->
										</tr>
									</thead>	
									<tbody></tbody>
								</table>
							</div>
						</div>
					</div>
					<!-- table 2 -->
					<div class="col-sm-<?=$colVal?>">
						<div class="card card-primary">
							<div class="card-header">
								<h3 class="card-title">Performance list (Processing)</h3>
								<div id="export_button_pro" class="float-right"></div>
							</div>
							<div class="card-body">
								<table class="table  table-hover table-sm small processing" id="processing_data_table" style="white-space: nowrap;">
									<thead>
										<tr>
											<th>ID</th>
											<!-- <th>Title</th>
											<th>Assigned By</th>
											<th>Processing By</th>
											<th>Time Left</th>
											<th>Action</th> -->
										</tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>
						</div>
					</div>
					<!-- d-head review table -->
					<?php if ($_SESSION['user_info']['d_head']=='1' AND $_SESSION['user_info']['d_head_reporting'] !=0) { ?>
					<div class="col-sm-<?=$colVal?>">
						<div class="card card-info">
							<div class="card-header">
								<h3 class="card-title">Review list</h3>
								<div id="export_button_rev" class="float-right"></div>
							</div>
							<div class="card-body">
								<table class="table  table-hover table-sm small processing" id="review_data_table" style="white-space: nowrap;">
									<thead>
										<tr>
											<th>ID</th>
											<!-- <th>Title</th>
											<th>Processing By</th>
											<th>Action</th> -->
										</tr>
									</thead>
									
									
								</table>
							</div>
						</div>
					</div>
					<?php } ?>
					<!-- table 3 -->
					<div class="col-sm-<?=$colVal?>">
						<div class="card card-success">
							<div class="card-header">
								<h3 class="card-title">Performance list (Completed)</h3>
								<div id="export_button_com" class="float-right"></div>
							</div>
							<div class="card-body">
								<table class="table  table-hover table-sm small" id="complete_data_table">
									<thead>
										<tr>
											<th>ID</th>
											<!-- <th>Title</th>
											<th>Assigned By</th>
											<th>Completed By</th>
											<th>Completed At</th>
											<th>Action</th> -->
										</tr>
									</thead>
									<tbody></tbody>
										
								</table>
							</div>
						</div>
					</div>
				</div>				
			</div>
		</div>
	</div>
</div>



<!-- Veiw Modal -->
<div class="modal fade processing_modal" id="exampleModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Performance Info</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="task_item">
        ...
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<!-- Add Task Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title addTask" id="staticBackdropLabel">Add New Performance</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="card card-primary card-outline card-outline-tabs">
					<div class="card-header p-0 border-bottom-0">
						<ul class="nav nav-tabs" id="custom-tabs-four-tab" style="border-bottom: 1px solid #dee2e6!important;" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="custom-tabs-four-home-tab" data-toggle="pill" href="#custom-tabs-four-home" role="tab" aria-controls="custom-tabs-four-home" aria-selected="true">Performance</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="custom-tabs-four-profile-tab" data-toggle="pill" href="#custom-tabs-four-profile" role="tab" aria-controls="custom-tabs-four-profile" aria-selected="false">Multi Performance</a>
							</li>										
						</ul>
					</div>
					<div class="card-body">
						<div class="tab-content" id="custom-tabs-four-tabContent">
							<div class="tab-pane fade active show" id="custom-tabs-four-home" role="tabpanel" aria-labelledby="custom-tabs-four-home-tab">
							
								<form role="form" action="<?=current_url(); ?>" method="POST" id="myform" enctype="multipart/form-data">
									<div class="card-body">
										<div class="row">
											<div class="col-sm-12">
												<div class="form-group">
												<?php if ($_SESSION['user_info']['department'] == '749568347163692080' ): ?>
													<label>Assinged To</label>
													<select class="form-control" id="employee_id" name="employee_id">
														<option selected value="">Choose...</option>
														<?php 
															$selectData=''; 
															foreach($result as $r){ 
																$selectData .= '<option value="'.$r->employee_id.'" data-img="'.$r->photo.'"> '.$r->full_name .' ('.$r->employee_id.')' .'</option>';
															};
															echo $selectData;
														?>
													</select>
												<?php endif; if($dep_head->d_head ==1 && $_SESSION['user_info']['department'] != '749568347163692080'): ?>
													<label>Assinged To</label>
													<select class="form-control" id="employee_id" name="employee_id" style="width:100%;" onchange="dHeadCheck(this);">
														<option selected value="">Choose...</option>
														<?php 
															$selectData=''; 
															foreach($emp_list as $r){ 
																$selectData .= '<option value="'.$r->employee_id.'" data-img="'.$r->photo.'" data-head="'.$r->d_head.'"> '.$r->full_name .' ('.$r->employee_id.')' .'</option>';
															};
															echo $selectData;
														?>
													</select>
												<?php endif;?>
												</div>
											</div>
											<?php if($dep_head->d_head==1 || $_SESSION['user_info']['department']=='749568347163692080'): ?>
											<div class="col-sm-12" >
												<label class="mr-2" >Bouns Type: </label>
												<br>
												<div class="form-check form-check-inline" >
													<input class="form-check-input" type="radio" name="bouns_type" value="none" id="inlineRadio1" checked >
													<label class="form-check-label" for="inlineRadio1" >Only Task</label>
												</div>
												<div class="form-check form-check-inline" >
													<input class="form-check-input" type="radio" name="bouns_type" value="positive" id="inlineRadio2" >
													<label class="form-check-label" for="inlineRadio2">Positive Performance</label>
												</div>
												<div class="form-check form-check-inline">
													<input class="form-check-input" type="radio" name="bouns_type" value="negative" id="inlineRadio3">
													<label class="form-check-label" for="inlineRadio3">Negative Performance</label>
												</div>
											</div>
											<div class="col-sm-12 TaskType" style="display:none;">
												<div class="d-flex">
													<div class="input-group">
														<input type="number" class="form-control" name="regular_point" min="0" placeholder="Point in percentage" disabled required >
													</div>
													<div class="input-group">
														<input type="number" class="form-control" placeholder="Amount" id="bouns_amount" readonly >
													</div>
												</div>
											</div>
											<?php endif; ?>
											<div class="col-sm-12">
												<div class="form-group">
													<label>Reason<span class="text-danger">*</span> </label>
													<input id="title" name="title" value="" type="text" class=" form-control" required>
													<span class="text-danger"><?php echo form_error('title');?> </span>
												</div>
											</div>
											<div class="col-sm-12">
												<div class="form-group">
													<label>Work Description (What need to do?)<span class="text-danger">*</span> </label>
													<textarea name="description" id="description" class="form-control" cols="30" rows="5" required></textarea>
													<span class="text-danger"><?php echo form_error('description');?> </span>
												</div>
											</div>
											<?php if($dep_head->d_head ==1 && $_SESSION['user_info']['department'] != '749568347163692080'): ?>
											<div class="col-sm-12">
												<div class="form-group">
													<label>How Company Benefited From This Task?</label>
													<textarea name="task_benefit" id="task_benefit" class="form-control" cols="30" rows="3"></textarea>
													<span class="text-danger"><?php echo form_error('description');?> </span>
												</div>
											</div>
											<?php endif; ?>
											<div class="row align-items-center ml-2" style="display:none;">
												<!-- <label for="rate" class="pt-2 mr-2">Priority :<span class="text-danger">*</span></label>
												<div class="rate">
													<input type="radio" id="star5" name="rate" value="5" checked required/>
													<label for="star5" title="text">5 stars</label>
													<input type="radio" id="star4" name="rate" value="4" />
													<label for="star4" title="text">4 stars</label>
													<input type="radio" id="star3" name="rate" value="3" />
													<label for="star3" title="text">3 stars</label>
													<input type="radio" id="star2" name="rate" value="2" />
													<label for="star2" title="text">2 stars</label>
													<input type="radio" id="star1" name="rate" value="1" />
													<label for="star1" title="text">1 star</label>
												</div> -->
											</div>
											<div class="col-sm-12">
												<label for="deadline">Task Complete Date :<span class="text-danger">*</span></label>
												<input type='date' id='deadline' name='deadline' class="form-control" required>
											</div>
											<div class="col-sm-12">
												<div class="form-group">
													<label>Image: </label>
													<div class="drop-zone"> <!--class="drop-zone" -->
														<span class="drop-zone__prompt">Drop file here or click to upload</span>
														<input type="file" name="image" id="image" class='form-control drop-zone__input'>  <!-- class="drop-zone__input" -->
													</div>
													<!-- <div class="input-group mb-3">
														<label class="input-group-text" for="inputGroupFile01">Upload</label>
														<input type="file" class="form-control" id="image" name="image">
													</div> -->
													<span class="text-danger"><?php echo form_error('description');?> </span>
												</div>
											</div>     
										</div>								
									</div>
									<div class="card-footer bg-white">
										<input type="hidden" name="save" value="save">
										<button type="submit" id="saveButton" name="save" value="save" class="btn btn-primary btn-small btn-block">Save</button>
									</div>
								</form>
							</div>
							<div class="tab-pane fade" id="custom-tabs-four-profile" role="tabpanel" aria-labelledby="custom-tabs-four-profile-tab">
								<form role="form" action="<?=current_url(); ?>" method="POST" id="myMultiTaskForm" enctype="multipart/form-data">
									<div class="card-body">
										<div class="row appendElement">
											<div class="col-sm-12">
												<div class="form-group">
												<?php if ($_SESSION['user_info']['department'] == '749568347163692080' ): ?>
													<label>Assinged To</label>
													<select class="form-control" id="employee_id2" name="employee_id2">
														<option selected value="">Choose...</option>
														<?php foreach($result as $r): ?>
														<option value="<?php echo $r->employee_id; ?>"><?php echo $r->full_name.' ('.$r->employee_id.')'; ?></option>
														<?php endforeach ?>
													</select>
												<?php endif; if($dep_head->d_head ==1 && $_SESSION['user_info']['department'] != '749568347163692080'): ?>
													<label>Assinged To</label>
													<select class="form-control" id="employee_id2" name="employee_id2" style="width:100%;" onchange="dHeadCheck(this);">
														<option selected value="">Choose...</option>
														<?php foreach($emp_list as $r): ?>
														<option value="<?php echo $r->employee_id; ?>" data-head="<?php echo $r->d_head; ?>"><?php echo $r->full_name.' ('.$r->employee_id.')'; ?></option>
														<?php endforeach ?>
													</select>
												<?php endif;?>
												</div>
											</div>
											<div class="col-sm-12 row cloneElement">
												<div class="col-sm-3">
													<div class="form-group" style=>
														<label>Title<span class="text-danger">*</span> </label>
														<input id="title" name="title2[]" value="" type="text" class=" form-control" required>
														<span class="text-danger"><?php echo form_error('title');?> </span>
													</div>
												</div>
												<div class="col-sm-3">
													<div class="form-group">
														<label>Description<span class="text-danger">*</span> </label>
														<textarea name="description2[]" id="description" class="form-control" cols="30" rows="1" required></textarea>
														<span class="text-danger"><?php echo form_error('description');?> </span>
													</div>
												</div>
												<?php if($dep_head->d_head ==1 && $_SESSION['user_info']['department'] != '749568347163692080'): ?>
												<div class="col-sm-3 TaskType">
													<label>Bouns point:</label>
													<div class="input-group">
														<div class="input-group-prepend">
															<div class="input-group-text">
																<input type="checkbox" name="task_type2[]" onchange="taskTypeChange(this,0);" value="regular">
															</div>
														</div>
														<input type="number" class="form-control" name="regular_point2[]" id="regular_point_0" min="5" max="100" placeholder="Point 5%-100%" disabled required>
													</div>
												</div>
												<?php endif; ?>
												<div class="col-sm-3">
													<div class="form-group">
														<label>Task Image: </label>
														<input type="file" name="image2[]" id="image" class='form-control'>  <!-- class="drop-zone__input" -->
													</div>
												</div>   
											</div> 
										</div>	
										
										<div class="row float-right mr-3">
											<button onclick="addButton(this,'add');" type="button" class="btn btn-sm btn-primary mr-1">Add</button>
											<button onclick="addButton(this,'delete');" type="button" class="btn btn-sm btn-danger">Delete</button>
										</div>							
									</div>
									<div class="card-footer bg-white">
										<input type="hidden" name="save_multi_task" value="save_multi_task">
										<button type="submit" id="saveMultiTaskButton" class="btn btn-primary btn-small btn-block">Save</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
			</div>
		</div>
	</div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="exampleModal2" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit/Confirmation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="edit_form">
        ...
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<?php 
$department ='';
foreach ($department_info as $key => $depart) {
    $department .= '<option value="'.$depart->department_id.'">'.$depart->department_name.'</option>';
  }

$employees ='';
foreach ($employee_info as $key => $employ) {
    $employees .= '<option value="'.$employ->employee_id.'">'.$employ->full_name.'</option>';
  }
?>

<!-- <script type="text/javascript" src="https://cdn.datatables.net/v/bs4-4.1.1/jq-3.3.1/dt-1.10.20/sc-2.0.1/datatables.min.js"></script> -->
<script src="<?=base_url('assets/plugins/datatables_scroller/datatables.min.js')?>"></script>
<style>
.dataTables_info{
	float: none !important;
}
#pending_data_table_paginate,#processing_data_table_paginate,#complete_data_table_paginate,#review_data_table_paginate{
	display: none;
}
#export_buttonscc button, #export_button_pro button, #export_button_com button, #export_button_rev button {
    padding: 0px 10px;
    background: #fff;
    border-radius: 4px;
	margin:0px;
}
.dts_label{
	display: none;
}
</style>
<script>
	var SL = 1 ; 
	function addButton(these,type) {
		if (type=='add') {
			var content = `<div class="col-sm-12 row cloneElement">
								<div class="col-sm-3">
									<div class="form-group" style=>
										<label>Title<span class="text-danger">*</span> </label>
										<input id="title" name="title2[]" value="" type="text" class=" form-control" required>
										<span class="text-danger"><?php echo form_error('title');?> </span>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<label>Description<span class="text-danger">*</span> </label>
										<textarea name="description2[]" id="description" class="form-control" cols="30" rows="1" required></textarea>
										<span class="text-danger"><?php echo form_error('description');?> </span>
									</div>
								</div>
								<?php if($dep_head->d_head ==1 && $_SESSION['user_info']['department'] != '749568347163692080'): ?>
								<div class="col-sm-3 TaskType">
									<label>Bouns point:</label>
									<div class="input-group">
										<div class="input-group-prepend">
											<div class="input-group-text">
												<input type="checkbox" name="task_type2[]" onchange="taskTypeChange(this,${SL});" value="regular">
											</div>
										</div>
										<input type="number" class="form-control" name="regular_point2[]" id="regular_point_${SL}" min="5" max="100" placeholder="Point 5%-100%" disabled required>
									</div>
								</div>
								<?php endif; ?>
								<div class="col-sm-3">
									<div class="form-group">
										<label>Task Image: </label>
										<input type="file" name="image2[]" id="image" class='form-control'>  <!-- class="drop-zone__input" -->
									</div>
								</div>   
							</div> `;
			$( content ).clone().appendTo( ".appendElement" );
			SL++;
		}else{
			$( ".cloneElement:last" ).remove();
		}
	}
	function formatState (state) {
		if (!state.id) {
			return state.text;
		}
		var $state = $(
			'<span><img src="' + '<?=base_url();?>' + state.element.dataset.img + '" class="img-flag rounded-circle border border-secondary" height="40px;"  width="40px;" /> ' + state.text + '</span>'
		);
		return $state;
	};


	$(document).ready(function() {
		// Initialize Select2 on modal show events
		$('#staticBackdrop').on('show.bs.modal', function() {
			$('#employee_id').select2({
				dropdownParent: $(this),
				templateResult: formatState
			});
		});

		$('#exampleModal2').on('show.bs.modal', function() {
			setTimeout(() => {
				$('.select22').select2({
					dropdownParent: $(this)
				});
			}, 1000);
		});
	});
	//=========DATA TABLE =========================
	var total_height = $(window).height();
	var task_height = total_height - 68.15 - 60.8 - 75.6 - 56.8 - 15 - (39.73 + 31 + 57);
	$(document).ready( function () {		
		//alert(task_height);
		var filter = '';
		<?php if ($_SESSION['super_admin']['user_type'] == 'Super Admin' || $_SESSION['user_info']['d_head'] == 1) { ?>
		filter += '<select class="department_filter custom-select-sm form-control form-control-sm select2" style="max-width: 33.3%;" onchange="taskFilter(this,\'department\',\'pending\')">';
		filter += '<option value="">Filter by Department</option>';
		filter += '<?=$department?>';
		filter += '<option value="all">All</option>';
		filter += '</select>';
		<?php } ?>

		filter += '<select class="custom-select-sm form-control form-control-sm select2" style="max-width: 33.3%;" onchange="taskFilter(this,\'employee\',\'pending\')">';
		filter += '<option value="">Filter by Employee</option>';
		filter += '<?=$employees?>';
		filter += '</select>';

		filter += '<input type="text" class="datepicker custom-select-sm  form-control-sm" id="pendingDatepicker" style="width: 33.3%;border: 1px solid #ced4da;" placeholder="Filter by Date" name="month_year" onchange="taskFilter(this,\'date\',\'pending\')" autocomplete="off">';
		setTimeout(() => {
			add_filter = '<div class="d-flex justify-content-between">' + filter + '</div>';
      		$('#pending_data_table_wrapper').prepend(add_filter);
			$('.select2').select2();
		}, 500);

		table = $('#pending_data_table').DataTable({
			"paging": true,
			"language": {  "infoFiltered": "" },
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"order": [[ 0, "desc" ]],
			scrollY:  task_height,
			scroller: {
				boundaryScale: 0.5,
				  displayBuffer: 20,
				  loadingIndicator: true,
				  serverWait: 10
			},
			deferRender: true,					
			"processing": false,
			"serverSide": true,  
			"ajax"	: {
				url			: "<?=current_url(); ?>",
				data    	: {"pending-data-table":'active'},
				type		: 'POST',
				beforeSend	: function(){  },
				complete	: function(){ 
					$('.colorClass').each(function(){
						if ($(this).val()==1) {
							$(this).closest("tr").css({"background-color": "#5bff7324","color": "#2c00ff"})
						}
					})
				}			
			},     
			"dom": 'lBfrtip',
			"buttons": [			
				{ extend: 'copy', text: '<i class="fas fa-copy"></i>', titleAttr: 'Copy', exportOptions: { columns: ':visible' } }, 
				{ extend: 'csv', text: '<i class="fas fa-file-csv"></i>', titleAttr: 'CSV', exportOptions: { columns: ':visible' } }, 
				{ extend: 'pdf', exportOptions: { columns: ':visible' }, orientation: 'landscape', pageSize: "LEGAL", text: '<i class="fas fa-file-pdf"></i>', titleAttr: 'PDF' }, 
				{ extend: 'print', text: '<i class="fas fa-print"></i>', titleAttr: 'Print', exportOptions: { columns: ':visible' } }, 
				{extend: 'colvis', text: '<i class="fas fa-list"></i>', titleAttr: 'Column Visibility' } 
			]
		});
		table.buttons().container().appendTo($('#export_buttonscc'));	
	});
	$(document).ready( function () {
		var filter = '';
		<?php if ($_SESSION['super_admin']['user_type'] == 'Super Admin' || $_SESSION['user_info']['d_head'] == 1) { ?>
		filter += '<select class="department_filter custom-select-sm form-control form-control-sm select2" style="max-width: 33.3%;" onchange="taskFilter(this,\'department\',\'process\')">';
		filter += '<option value="">Filter by Department</option>';
		filter += '<?=$department?>';
		filter += '<option value="all">All</option>';
		filter += '</select>';
  		<?php } ?>
		
		filter += '<select class="custom-select-sm form-control form-control-sm select2" style="max-width: 33.3%;" onchange="taskFilter(this,\'employee\',\'process\')">';
		filter += '<option value="">Filter by Employee</option>';
		filter += '<?=$employees?>';
		filter += '</select>';

		filter+=`<input type="text" class="datepicker department_filter custom-select-sm  form-control-sm" id="datepicker" placeholder="Filter by Date" name="month_year" style="width: 33.3%;border: 1px solid #ced4da;" onchange="taskFilter(this,\'date\',\'process\')" autocomplete="off">`;
		setTimeout(() => {
			add_filter = `<div class="d-flex justify-content-between">${filter}</div>`;
      		$('#processing_data_table_wrapper').prepend(add_filter);
			$('.select2').select2();
		}, 500);
		processing = $('#processing_data_table').DataTable({
			"paging": true,
			"language": {  "infoFiltered": "" },
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"order": [[ 0, "desc" ]],
			scrollY:  task_height,
			scroller: {
				boundaryScale: 0.5,
				displayBuffer: 20,
				loadingIndicator: true,
				serverWait: 10
			},
			deferRender: true,					
			"processing": false,
			"serverSide": true,   
			"ajax"	: {
				url			: "<?=current_url(); ?>",
				data    	: {"processing-data-table":'active'},
				type		: 'POST',
				beforeSend	: function(){  },
				complete	: function(){ // timer for task period
					$(".demo").each(function(index){
						var obj=$(this);
						var countDownDate=new Date(obj.data('val')).getTime();
						var x=setInterval(function(obj,countDownDate){
							var now=new Date().getTime();
							var distance=countDownDate-now;
							// If the count down is over 
							if (distance<0){
								// clearInterval(x);
								// obj.text("EXPIRED");
								
								// Time calculations for days, hours, minutes and seconds
								var dist=now-countDownDate;
								var days = Math.floor(dist / (1000 * 60 * 60 * 24));
								var hours = Math.floor((dist % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
								var minutes = Math.floor((dist % (1000 * 60 * 60)) / (1000 * 60));
								var seconds = Math.floor((dist % (1000 * 60)) / 1000);
								obj.text('-'+days+"d "+hours+"h "+minutes+"m "+seconds+"s ");
							}else{
								// Time calculations for days, hours, minutes and seconds
								var days = Math.floor(distance / (1000 * 60 * 60 * 24));
								var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
								var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
								var seconds = Math.floor((distance % (1000 * 60)) / 1000);
								obj.text(days+"d "+hours+"h "+minutes+"m "+seconds+"s ");
							}
						}, 1000,obj,countDownDate);
					});
				}			
			},     
			"dom": 'lBfrtip',
			"buttons": [			
			{
				extend: 'copy',
				text: '<i class="fas fa-copy"></i>',
				titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'csv',
				text: '<i class="fas fa-file-csv"></i>',
				titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
				text: '<i class="fas fa-file-pdf"></i>',
				titleAttr: 'PDF'
			}, 
			{
				extend: 'print',
				text: '<i class="fas fa-print"></i>',
				titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'colvis',
				text: '<i class="fas fa-list"></i>',
				titleAttr: 'Column Visibility'
			}
		],

		});
		processing.buttons().container().appendTo($('#export_button_pro'));	
	});
	$(document).ready( function () {
		var filter = '';
		<?php if ($_SESSION['super_admin']['user_type'] == 'Super Admin' || $_SESSION['user_info']['d_head'] == 1) { ?>
		filter += '<select class="department_filter custom-select-sm form-control form-control-sm select2" style="max-width: 33.3%;" onchange="taskFilter(this,\'department\',\'complete\')">';
		filter += '<option value="">Filter by Department</option>';
		filter += '<?=$department?>';
		filter += '<option value="all">All</option>';
		filter += '</select>';
  		<?php } ?>	
		
		filter += '<select class="custom-select-sm form-control form-control-sm select2" style="max-width: 33.3%;" onchange="taskFilter(this,\'employee\',\'complete\')">';
		filter += '<option value="">Filter by Employee</option>';
		filter += '<?=$employees?>';
		filter += '</select>';

		filter+=`<input type="text" class="datepicker department_filter custom-select-sm  form-control-sm" id="datepicker" placeholder="Filter by Date" name="month_year" style="width: 33.3%;border: 1px solid #ced4da;" onchange="taskFilter(this,\'date\',\'complete\')" autocomplete="off">`;
		setTimeout(() => {
			add_filter = `<div class="d-flex justify-content-between">${filter}</div>`;
      		$('#complete_data_table_wrapper').prepend(add_filter);
			$('.select2').select2();
		}, 800);
		complete = $('#complete_data_table').DataTable({
			"paging": true,
			"language": {  "infoFiltered": "" },
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"order": [[ 0, "desc" ]],
			scrollY:  task_height,
			scroller: {
				boundaryScale: 0.5,
				displayBuffer: 20,
				loadingIndicator: true,
				serverWait: 10
			},
			deferRender: true,					
			"processing": false,
			"serverSide": true,   
			"ajax"	: {
				url			: "<?=current_url(); ?>",
				data    	: {"complete-data-table":'active'},
				type		: 'POST',
				beforeSend	: function(){  },
				complete	: function(){ 
				}			
			},     
			"dom": 'lBfrtip',
			"buttons": [			
			{
				extend: 'copy',
				text: '<i class="fas fa-copy"></i>',
				titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'csv',
				text: '<i class="fas fa-file-csv"></i>',
				titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
				text: '<i class="fas fa-file-pdf"></i>',
				titleAttr: 'PDF'
			}, 
			{
				extend: 'print',
				text: '<i class="fas fa-print"></i>',
				titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'colvis',
				text: '<i class="fas fa-list"></i>',
				titleAttr: 'Column Visibility'
			}
		],

		});
		complete.buttons().container().appendTo($('#export_button_com'));	
	} );

	$(document).ready( function () {
		<?php if (isset($_SESSION['user_info']) && $_SESSION['user_info']['d_head']=='1') { ?>
		var filter = '';
		<?php if ($_SESSION['super_admin']['user_type'] == 'Super Admin' || $_SESSION['user_info']['d_head'] == 1) { ?>
		filter += '<select class="department_filter custom-select-sm form-control form-control-sm select2" style="max-width: 33.3%;" onchange="taskFilter(this,\'department\',\'review\')">';
		filter += '<option value="">Filter by Department</option>';
		filter += '<?=$department?>';
		filter += '</select>';
  		<?php } ?>
		
		filter += '<select class="custom-select-sm form-control form-control-sm select2" style="max-width: 33.3%;" onchange="taskFilter(this,\'employee\',\'review\')">';
		filter += '<option value="">Filter by Employee</option>';
		filter += '<?=$employees?>';
		filter += '</select>';

		filter+=`<input type="text" class="datepicker department_filter custom-select-sm  form-control-sm" id="datepicker" placeholder="Filter by Date" name="month_year" style="width: 33.3%;border: 1px solid #ced4da;" onchange="taskFilter(this,\'date\',\'review\')" autocomplete="off">`;
		setTimeout(() => {
			add_filter = `<div class="d-flex justify-content-between">${filter}</div>`;
      		$('#review_data_table_wrapper').prepend(add_filter);
			$('.select2').select2();
		}, 1000);
		review = $('#review_data_table').DataTable({
			"paging": true,
			"language": {  "infoFiltered": "" },
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"order": [[ 0, "desc" ]],
			scrollY:  task_height,
			scroller: {
				boundaryScale: 0.5,
				displayBuffer: 20,
				loadingIndicator: true,
				serverWait: 10
			},
			deferRender: true,					
			"processing": false,
			"serverSide": true,  
			"ajax"	: {
				url			: "<?=current_url(); ?>",
				data    	: {"review-data-table":'active'},
				type		: 'POST',
				beforeSend	: function(){  },
				complete	: function(){ 
				}			
			},     
			"dom": 'lBfrtip',
			"buttons": [			
			{
				extend: 'copy',
				text: '<i class="fas fa-copy"></i>',
				titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'csv',
				text: '<i class="fas fa-file-csv"></i>',
				titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
				text: '<i class="fas fa-file-pdf"></i>',
				titleAttr: 'PDF'
			}, 
			{
				extend: 'print',
				text: '<i class="fas fa-print"></i>',
				titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
			}, 
			{
				extend: 'colvis',
				text: '<i class="fas fa-list"></i>',
				titleAttr: 'Column Visibility'
			}
		],

		});
		review.buttons().container().appendTo($('#export_button_rev'));	
		<?php } ?>
	} );


	setTimeout(() => {
		$( function() {
			$( ".datepicker" ).datepicker({
				format: "yyyy-mm",
				startView: "months", 
				minViewMode: "months"
			});
		});
	
	}, 3000);

	function taskFilter(thes,type,taskType){
		var department = '';
		var date = '';
		var employee = '';
		if (type == 'department') {
			department = thes.value
		}else if(type == 'date'){
			date = thes.value
		}else if(type == 'employee'){
			employee = thes.value
		}
		if (thes.value.trim() != '') {
			if (taskType == 'pending') {
				var ajax_data = "<?=base_url('admin/s_it/tasks')?>?pending-data-table=active&departments="+department+"&employee="+employee+"&date="+date;
				$('#pending_data_table').DataTable().ajax.url(ajax_data).load();
			}else if(taskType == 'process'){
				var ajax_data = "<?=base_url('admin/s_it/tasks')?>?processing-data-table=active&departments="+department+"&employee="+employee+"&date="+date;
				$('#processing_data_table').DataTable().ajax.url(ajax_data).load();
			}else if(taskType == 'complete'){
				var ajax_data = "<?=base_url('admin/s_it/tasks')?>?complete-data-table=active&departments="+department+"&employee="+employee+"&date="+date;
				$('#complete_data_table').DataTable().ajax.url(ajax_data).load();
			}else if(taskType == 'review'){
				var ajax_data = "<?=base_url('admin/s_it/tasks')?>?review-data-table=active&departments="+department+"&employee="+employee+"&date="+date;
				$('#review_data_table').DataTable().ajax.url(ajax_data).load();
			}
		}
	}

	function pointForm(taskId) {
		$.ajax({
			url: "<?php echo base_url("admin/s_it/task-detail"); ?>",
			method: "POST",
			dataType: "HTML",
			data: {task_info : taskId, get_point_form:'yes'},
			success: function(data){
				$(".processing_modal").modal('show');
				$("#task_item").html(data);
			}
			
		})
	}

	// for multi task point
	function taskTypeChange(these,i) {
		var taskType = $(these).is(':checked');
		if (taskType) {
			$('#regular_point_'+i).prop('disabled', false);
		}else{
			$('#regular_point_'+i).prop('disabled', true);
		}
	}

	$(document).ready(function(){
			// $('#myTable').DataTable();
		$('input[name="bouns_type"]').on("change",function() {
			var bounsType = $('input[name="bouns_type"]:checked').val();
			if (bounsType=='none') {
				$(".TaskType").hide();
				$('#task_benefit').prop('required', false);
				$('input[name="regular_point"]').prop('disabled', true);
			}else{
				var empId = $("#employee_id").val();
				var dHeadStatus = $("#employee_id").find(':selected').data('head');
				if (empId == '' || empId == undefined) {
					$('input[type="radio"][name="bouns_type"][value="none"]').prop('checked', true).change();
					alert('Choose Employee First!');
				}
				else if (dHeadStatus==1 || employee_id=='<?=$_SESSION['super_admin']['employee_ids']?>') {
					$(".TaskType").hide();
					$('input[type="radio"][name="bouns_type"][value="none"]').prop('checked', true).change();
					alert('Cannot give bonus dhead or myself!');
				}
				else{
					if (bounsType=='positive') {
						$("#bouns_amount").css({ 'color': 'green' });
					}else{
						$("#bouns_amount").css({ 'color': 'red' });
					}
					$(".TaskType").show();
					$('#task_benefit').prop('required', true);
					$('input[name="regular_point"]').prop('disabled', false);
				}
			}
		}) 
		//  for submit form with ajax
		$("#myform").on('submit',(function(e) {
			e.preventDefault();
			$.ajax({
				url: "<?=base_url('admin/s_it/task_create'); ?>",
				type: "POST",
				data:  new FormData(this),
				contentType: false,
				cache: false,
				processData:false,
				beforeSend: function(param){
					$("#saveButton").prop('disabled', true).html('<span class="spinner-border spinner-border-sm text-warning" role="status" aria-hidden="true"></span>Procesing...');
				},
				success: function(result)
				{
					$("#myform")[0].reset();
					$(".drop-zone__thumb").remove();
					$(".drop-zone__prompt").remove();
					$("#myform .drop-zone").prepend('<span class="drop-zone__prompt">Drop file here or click to upload</span>');
					// $(".queue").html(new_data['html']);
					$('#pending_data_table,#processing_data_table,#review_data_table,#complete_data_table').DataTable().ajax.reload( null , false);
					$("#staticBackdrop .close").click();
					$("#exampleModal2 .close").click();
					$('input[type="radio"]').prop('checked', false);
					$('#task_benefit').prop('required', false);
					$('input[name="regular_point"]').prop('disabled', true);
					$("#saveButton").prop('disabled', false).html('Save');
					swal.fire({
						title: "Success!",
						text: "Data created !",
						icon: "success",
						button: "Ok",
					});
				},
				error: function() 
				{
					//window.location.reload();
				} 	        
			});
		}));

		
		$("#myMultiTaskForm").on('submit',(function(e) {
			e.preventDefault();
			$.ajax({
				url: "<?=base_url('admin/s_it/task_create'); ?>",
				type: "POST",
				data:  new FormData(this),
				contentType: false,
				cache: false,
				processData:false,
				beforeSend: function(param){
					$("#saveMultiTaskButton").prop('disabled', true).html('<span class="spinner-border spinner-border-sm text-warning" role="status" aria-hidden="true"></span>Procesing...');
				},
				success: function(result)
				{
					$("#myMultiTaskForm")[0].reset();
					// $(".queue").html(new_data['html']);
					$('#pending_data_table,#processing_data_table,#review_data_table,#complete_data_table').DataTable().ajax.reload( null , false);
					$("#staticBackdrop .close").click();
					$("#exampleModal2 .close").click();
					$('input[type="radio"]').prop('checked', false);
					$('input[name="regular_point"]').prop('disabled', true);
					$("#saveMultiTaskButton").prop('disabled', false).html('Save');
					swal.fire({
						title: "Success!",
						text: "Data created !",
						icon: "success",
						button: "Ok",
					});
				},
				error: function() 
				{
					//window.location.reload();
				} 	        
			});
		}));


		//  view page with modal
		$(document).on('click', ".task_veiw", function(e){
			e.preventDefault(); 
			var task_info = $(this).data("task_info");
			$.ajax({
				url: "<?php echo base_url("admin/s_it/task-detail"); ?>",
				method: "POST",
				dataType: "HTML",
				data: {task_info : task_info},
				success: function(data){
					$(".processing_modal").modal('show');
					$("#task_item").html(data);
				}
				
			})
		});

		

		//  task edit page with modal
		$(document).on('click', ".task_edit", function(e){
			e.preventDefault();
			var task_edit = $(this).data("task_edit");
			$.ajax({
				url: "<?php echo base_url("admin/s_it/tasks"); ?>",
				method: "POST",
				dataType: "HTML",
				data: {"task_edit": task_edit},
				success: function(data){
					$("#edit_form").empty();
					$("#edit_form").html(data);
				}
				
			})
		});

		//  task accept page with modal
		$(document).on('click', ".accept", function(e){
			e.preventDefault();
			var task_accept = $(this).data("task_accept");
			$.ajax({
				url: "<?php echo base_url("admin/s_it/tasks"); ?>",
				method: "POST",
				dataType: "HTML",
				data: {"task_accept_id": task_accept},
				success: function(data){
					$("#edit_form").html(data);
					
				}
				
			})
		});

		//  task complete page with modal
		$(document).on('click', ".complete", function(e){
			$('#exampleModal').modal('show');
			e.preventDefault();
			var task_complete = $(this).data("task_complete");
			$.ajax({
				url: "<?php echo base_url("admin/s_it/tasks"); ?>",
				method: "POST",
				dataType: "HTML",
				data: {"task_complete_id": task_complete},
				success: function(data){
					$("#task_item").html(data);
					$('#exampleModal').modal('show');
					
				}
				
			})

		});

		

		$(document).on("click", "#accept", function(){
			event.preventDefault();
			var id = $(this).attr('data-task_id');
			
			$(".queue").find('[data-row="'+ id +'"]').remove();
			$.ajax({
				url: "<?php echo base_url('admin/s_it/task_accept') ?>",
				type: 'post',
				data: $("#task_edit_form").serialize(),
				success: function(data) {
					if (data=='success') {
						$('#pending_data_table,#processing_data_table,#review_data_table,#complete_data_table').DataTable().ajax.reload( null , false);
						// $(".processing_body").html(new_data['html']);
						$("#exampleModal2 .close").click();
						$(".processing_modal .close").click();
						swal.fire({
							title: "Success!",
							text: "Data updated !",
							icon: "success",
							button: "Ok",
						});
					}else{
						toastr.error('Something Wrong!');
					}
				}
			});
		})

	});

	// drag & drop upload file script
	document.querySelectorAll(".drop-zone__input").forEach((inputElement) => {
		const dropZoneElement = inputElement.closest(".drop-zone");
		const form = inputElement.closest("form");
		// const form = document.getElementById("myform");

		dropZoneElement.addEventListener("click", (e) => {
			inputElement.click();
		});

		inputElement.addEventListener("change", (e) => {
			if (inputElement.files.length) {
			updateThumbnail(dropZoneElement, inputElement.files[0]);
			}
		});
		
		form.addEventListener('paste', e => {
			inputElement.files = e.clipboardData.files;
			if (inputElement.files.length) {
			updateThumbnail(dropZoneElement, inputElement.files[0]);
			}
		});

		dropZoneElement.addEventListener("dragover", (e) => {
			e.preventDefault();
			dropZoneElement.classList.add("drop-zone--over");
		});

		["dragleave", "dragend"].forEach((type) => {
			dropZoneElement.addEventListener(type, (e) => {
			dropZoneElement.classList.remove("drop-zone--over");
			});
		});

		dropZoneElement.addEventListener("drop", (e) => {
			e.preventDefault();

			if (e.dataTransfer.files.length) {
			inputElement.files = e.dataTransfer.files;
			updateThumbnail(dropZoneElement, e.dataTransfer.files[0]);
			}

			dropZoneElement.classList.remove("drop-zone--over");
		});
	});

	/**
	 * Updates the thumbnail on a drop zone element.
	 *
	 * @param {HTMLElement} dropZoneElement
	 * @param {File} file
	 */
	function updateThumbnail(dropZoneElement, file) {
		let thumbnailElement = dropZoneElement.querySelector(".drop-zone__thumb");

		// First time - remove the prompt
		if (dropZoneElement.querySelector(".drop-zone__prompt")) {
			dropZoneElement.querySelector(".drop-zone__prompt").remove();
		}

		// First time - there is no thumbnail element, so lets create it
		if (!thumbnailElement) {
			thumbnailElement = document.createElement("div");
			thumbnailElement.classList.add("drop-zone__thumb");
			dropZoneElement.appendChild(thumbnailElement);
		}

		thumbnailElement.dataset.label = file.name;

		// Show thumbnail for image files
		if (file.type.startsWith("image/")) {
			const reader = new FileReader();

			reader.readAsDataURL(file);
			reader.onload = () => {
			thumbnailElement.style.backgroundImage = `url('${reader.result}')`;
			};
		} else {
			thumbnailElement.style.backgroundImage = null;
		}
	}

	//  for paste image
	// const form = document.getElementById("myform");
	// const fileInput = document.getElementById("image");


	// form.addEventListener('paste', e => {
	// fileInput.files = e.clipboardData.files;
	// 	if (inputElement.files.length) {
	// 	updateThumbnail(dropZoneElement, inputElement.files[0]);
	// 	}
	// });
	
	// send reveiw modal
	function reviewModal(id) {
		$.ajax({
			url: "<?php echo base_url("admin/s_it/tasks"); ?>",
			method: "POST",
			dataType: "HTML",
			data: {"task_id": id, "review_form":"yes"},
			success: function(data){
				$("#task_item").html(data);
				$('#exampleModal').modal('show');
				
			}
		})
	}

	// feedback modal
	function feedbackModal(id) {
		$.ajax({
			url: "<?php echo base_url("admin/s_it/tasks"); ?>",
			method: "POST",
			dataType: "HTML",
			data: {"task_id": id, "feedback_form":"yes"},
			success: function(data){
				$("#task_item").html(data);
				$('#exampleModal').modal('show');
				
			}
		})
	}

	setTimeout(() => {
		$(function () {
			$('[data-toggle="tooltip"]').tooltip();
		})
	}, 2000);

	// function copyToClipboard(text,these) {
	// 	var temp = $("<input>");
	// 	$("body").append(temp);
	// 	temp.val(text).select();
	// 	document.execCommand("copy");
	// 	temp.remove();
	// 	$(these).attr("data-original-title", "Copied: "+text).tooltip('show');
	// 	$(these).attr("data-original-title", text);
	// }
	const copyToClipboard = async (text,these) => {
		try {
			var $temp = $("<input>");
			$("body").append($temp);
			$temp.val(text).select();
			document.execCommand("copy");
			// $temp.remove();
			// await navigator.clipboard.writeText(text);
			$(these).attr("data-original-title", "Copied: "+text).tooltip('show');
			$(these).attr("data-original-title", text);
		} catch (err) {
			console.error('Failed to copy: ', err);
		}
	}

	function backToPending(taskId) {
		if (confirm('Are you sure about action?')) {
			$.ajax({
				url: "<?php echo base_url("admin/s_it/tasks"); ?>",
				method: "POST",
				dataType: "HTML",
				data: {"task_id": taskId, "send_to_pending_list":"yes"},
				success: function(data){
					$('#pending_data_table,#processing_data_table,#review_data_table,#complete_data_table').DataTable().ajax.reload( null , false);
					if (data=='success') {
						swal.fire({
							title: "Success!",
							text: "Data updated !",
							icon: "success",
							button: "Ok",
						});
					}
				}
			})
		}else{
			return false;
		}
	}

	function dHeadCheck(thes){
		var employee_id = $(thes).val();
		var dHeadStatus = $(thes).find(':selected').data('head');
		if (dHeadStatus==1 || employee_id=='<?=$_SESSION['super_admin']['employee_ids']?>') {
			$(".TaskType").hide();
			$('input[type="radio"][name="bouns_type"][value="none"]').prop('checked', true).change();
		}else{
			var bounsType = $('input[name="bouns_type"]:checked').val();
			if (bounsType=='none') {
				$(".TaskType").hide();
			}else{
				$(".TaskType").show();
			}
		}
	}

	$('input[name="regular_point"]').on("keyup change",function(){
		var point = $(this).val();
		var employee_id = $("#employee_id").val();
		$.ajax({
			url: "<?php echo base_url("admin/s_it/task_create"); ?>",
			method: "POST",
			dataType: "HTML",
			data: {"task_point": point, "employee_id":employee_id, "get_bouns_amount":"yes"},
			// beforeSend:function(){ 

			// },
			success: function(data){
				if (data != '') {
					$("#bouns_amount").val(data);
				}
			}
		})
	});
</script>
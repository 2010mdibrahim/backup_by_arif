<div class="card card-primary">
		<div class="card-header">
			<h3 class="card-title">Assign a Task</h3>
		</div>
		<form role="form" action="<?=base_url('admin/s_it/tasks'); ?>" method="POST" id="myform" class="task_update_form" enctype="multipart/form-data">
		<input type="hidden" name="update_id" value="<?php if(!empty($edit)){ echo $edit->id; } ?>"/>
			<div class="card-body">
				<div class="row">
				
					<div class="col-sm-12">
						<div class="form-group">
							
							<?php if ($_SESSION['user_info']['department']=='749568347163692080'): ?>

							<label>Assinged To</label>
							<select class="form-control select22" id="employee_id" name="employee_id">
								<option selected value="">Choose...</option>
								<?php foreach($emp_list as $r): ?>
								<option value="<?php echo $r->employee_id; ?>" 
								<?php 
								if(!empty($edit)){ 
									if($edit->assigned_to == $r->employee_id || $edit->processing_by == $r->employee_id){ 
										$select = 'selected';
									}else{ 
										$select = null;
									} 
									echo $select ;
								}
								?>
								
								><?php echo $r->full_name; ?></option>
								<?php endforeach; ?>
							</select>
							
							
						<?php endif; if($dep_head->d_head==1 && $_SESSION['user_info']['department']!='749568347163692080'):?>
							<label>Assinged To</label>
							<select class="form-control select22" id="edit_employee_id" name="employee_id">
								<option selected value="">Choose...</option>
								<?php foreach($emp_list as $r) { ?>
								<option value="<?php echo $r->employee_id; ?>"  
								<?php 
								if(!empty($edit)){ 
									if($edit->assigned_to == $r->employee_id || $edit->processing_by == $r->employee_id){ 
										$select = 'selected';
									}else{ 
										$select = null;
									} 
									echo $select ;
								}
								?>
								><?php echo $r->full_name; ?></option>
								<?php } ?>
							</select>
						<?php endif; ?>
						</div>
					</div>
					<?php if($dep_head->d_head==1 || $_SESSION['user_info']['department']=='749568347163692080'): ?>
					<div class="col-sm-12" >
						<label class="mr-2" >Bouns Type: </label>
						<br>
						<div class="form-check form-check-inline" >
							<input class="form-check-input" type="radio" name="edit_bouns_type" value="none" id="inlineRadio1" <?php echo empty($edit_point->id) ? 'checked':''?> >
							<label class="form-check-label" for="inlineRadio1" >Only Task</label>
						</div>
						<div class="form-check form-check-inline" >
							<input class="form-check-input" type="radio" name="edit_bouns_type" value="positive" id="inlineRadio2" <?php echo !empty($edit_point->task_point) &&  $edit_point->task_point>0 ? 'checked':''?> >
							<label class="form-check-label" for="inlineRadio2">Positive Performance</label>
						</div>
						<div class="form-check form-check-inline">
							<input class="form-check-input" type="radio" name="edit_bouns_type" value="negative" id="inlineRadio3" <?php echo !empty($edit_point->task_point) &&  $edit_point->task_point<0 ? 'checked':''?>>
							<label class="form-check-label" for="inlineRadio3">Negative Performance</label>
						</div>
					</div>
					<div class="col-sm-12 TaskType" style="display: <?php echo empty($edit_point->id) ? 'none':''?>;">
						<div class="d-flex">
							<div class="input-group">
								<input type="number" class="form-control" name="edit_regular_point" min="0" placeholder="Point in percentage" value="<?php echo !empty($edit_point->task_point) ? abs($edit_point->task_point) : '' ?>" <?php echo empty($edit_point->id) ? 'disabled':''?> required >
							</div>
							<div class="input-group">
								<input type="number" class="form-control" placeholder="Amount" id="edit_bouns_amount" readonly >
							</div>
						</div>
					</div>
					<?php endif; ?>
					<div class="col-sm-12">
						<div class="form-group">
							<label>Task Title<span class="text-danger">*</span> </label>
							<input id="title" name="title" value="<?php if(!empty($edit)){ echo $edit->title; } ?>" type="text" class=" form-control" required>
							<span class="text-danger"><?php echo form_error('title');?> </span>
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group">
							<label>Task Description<span class="text-danger">*</span> </label>
							<textarea name="description" id="description" class="form-control" cols="30" rows="5" required><?php if(!empty($edit)){ echo $edit->description; } ?></textarea>
							<span class="text-danger"><?php echo form_error('description');?> </span>
						</div>
					</div>
					<!-- <div class="col-sm-12">
						<label for="deadline">Task Deadline <small class="text-danger">(optional)</small> :  </label>
						<input type='date' id='deadline' name='deadline' min='<?= date("Y-m-d"); ?>'>
					</div> -->
					<div class="col-sm-6">
						<div class="form-group">
							<label>Task Image </label>
							<div class="drop-zone"> <!--class="drop-zone" -->
								<span class="drop-zone__prompt">Drop file here or click to upload</span>
								<input type="file" name="image" id="image" class='form-control drop-zone__input'>  <!-- class="drop-zone__input" -->
							</div>
							<span class="text-danger"><?php echo form_error('description');?> </span>
						</div>
					</div>
					<?php if (!empty($edit) && !empty($edit->task_image)): ?>
						<div class="col-sm-6"><img class="w-100 imgFrame" src="<?= base_url()?>assets/uploads/task_list/<?= $edit->task_image ?>" alt="Task image"></div>
					<?php endif; ?>      
				</div>								
			</div>
			
			<div class="card-footer bg-white">
				<button type="submit" id="update" name="update" class="btn btn-warning btn-small btn-block">Update</button>
			</div>
		</form>
	</div>



<script>
	// setTimeout(() => {
	// 	$(".select22").select2({
	// 		dropdownParent: $(".task_update_form")
	// 	});
	// }, 500);

	$(".task_update_form").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
			url: "<?=base_url('admin/s_it/task_update'); ?>",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
			cache: false,
			processData:false,
			success: function(result)
			{
				
				$(".task_update_form")[0].reset();
				$('#pending_data_table,#processing_data_table,#review_data_table,#complete_data_table').DataTable().ajax.reload( null , false);
				$("#exampleModal2 .close").click();
				swal.fire({
					title: "Success!",
					text: "Data updated !",
					icon: "success",
					button: "Ok",
				});
			},
			error: function() 
			{
				console.log("Error: task update.");
				//window.location.reload();
			} 	        
		});
	}));

	//  for paste image
	// var forms = document.getElementById("exampleModal2");
	// var fileInputs = document.querySelector("#images");


	// forms.addEventListener('paste', e => {
	// 	fileInputs.files = e.clipboardData.files;
	// });

	// drag & drop upload file script
	document.querySelectorAll(".drop-zone__input").forEach((inputElement) => {
		const dropZoneElement = inputElement.closest(".drop-zone");
		const form = inputElement.closest("form");
		// const form = document.getElementById("myform");

		dropZoneElement.addEventListener("click", (e) => {
			inputElement.click();
		});

		inputElement.addEventListener("change", (e) => {
			if (inputElement.files.length) {
			updateThumbnail(dropZoneElement, inputElement.files[0]);
			}
		});
		
		form.addEventListener('paste', e => {
			inputElement.files = e.clipboardData.files;
			if (inputElement.files.length) {
			updateThumbnail(dropZoneElement, inputElement.files[0]);
			}
		});

		dropZoneElement.addEventListener("dragover", (e) => {
			e.preventDefault();
			dropZoneElement.classList.add("drop-zone--over");
		});

		["dragleave", "dragend"].forEach((type) => {
			dropZoneElement.addEventListener(type, (e) => {
			dropZoneElement.classList.remove("drop-zone--over");
			});
		});

		dropZoneElement.addEventListener("drop", (e) => {
			e.preventDefault();

			if (e.dataTransfer.files.length) {
			inputElement.files = e.dataTransfer.files;
			updateThumbnail(dropZoneElement, e.dataTransfer.files[0]);
			}

			dropZoneElement.classList.remove("drop-zone--over");
		});
	});

	
	$('input[name="edit_regular_point"]').on("keyup change",function(){
		var point = $(this).val();
		var employee_id = $("#edit_employee_id").val();
		$.ajax({
			url: "<?php echo base_url("admin/s_it/task_create"); ?>",
			method: "POST",
			dataType: "HTML",
			data: {"task_point": point, "employee_id":employee_id, "get_bouns_amount":"yes"},
			// beforeSend:function(){ 

			// },
			success: function(data){
				if (data != '') {
					$("#edit_bouns_amount").val(data);
				}
			}
		})
	});

	$(document).ready(function(){
			// $('#myTable').DataTable();
		$('input[name="edit_bouns_type"]').on("change",function() {
			var bounsType = $('input[name="edit_bouns_type"]:checked').val();
			if (bounsType=='none') {
				$(".TaskType").hide();
				$('#task_benefit').prop('required', false);
				$('input[name="edit_regular_point"]').prop('disabled', true);
			}else{
				var empId = $("#edit_employee_id").val();
				var dHeadStatus = $("#edit_employee_id").find(':selected').data('head');
				if (empId == '' || empId == undefined) {
					$('input[type="radio"][name="edit_bouns_type"][value="none"]').prop('checked', true).change();
					alert('Choose Employee First!');
				}
				else if (dHeadStatus==1 || employee_id=='<?=$_SESSION['super_admin']['employee_ids']?>') {
					$(".TaskType").hide();
					$('input[type="radio"][name="edit_bouns_type"][value="none"]').prop('checked', true).change();
					alert('Cannot give bonus dhead or myself!');
				}
				else{
					if (bounsType=='positive') {
						$("#edit_bouns_amount").css({ 'color': 'green' });
					}else{
						$("#edit_bouns_amount").css({ 'color': 'red' });
					}
					$(".TaskType").show();
					$('#task_benefit').prop('required', true);
					$('input[name="edit_regular_point"]').prop('disabled', false);
				}
			}
		}) 
		
		$('input[name="edit_regular_point"]').change();
	});
</script>
<div class="mx-4 card card-info">
    <div class="card-header">
        <h3 class="card-title">Send Task</h3>
    </div>
    <div class="card-body">
        <?php foreach ($task_review as $key => $value) { 
            $files = explode(',',$value->task_files);
            ?>
            <h5><i class="fas fa-user-circle"></i> <?=$value->emp_name?></h5>
                
            <div class="ml-4">
                <div><?=$value->feedback?></div>
                <?php foreach ($files as  $file) {
                    if (!empty($file)) {
                        echo '<a href="'.base_url($file).'" target="_blank"><img src="'.base_url($file).'" class="img-thumbnail" width="100px;"></a>';
                    }
                }?>
            </div>
            <?php } ?>
        <form action="" method="post" id="review_form" class="card-footer">
            <input type="hidden" name="review_submit">
            <input type="hidden" name="task_id" value="<?=$task_info->id?>">
            <div class="mb-3">
                <label for="validationTextarea">Task Description</label>
                <textarea class="form-control" id="validationTextarea" name="description" placeholder="Description, what you do?" required></textarea>
            </div>

            <div class="custom-file">
            <input type="file" class="custom-file-input" id="customFile" name="review_files[]" multiple>
            <label class="custom-file-label" for="customFile">Choose file</label>
            </div>
            <div class="text-right mt-3">
                <button type="submit" class="btn btn-sm btn-primary">Send to reviewer</button>
            </div>
        </form>
    </div>
</div>
<script>
    $("#review_form").on('submit',function (e) {
        e.preventDefault();
        
        $.ajax({
            url: "<?php echo base_url("admin/s_it/tasks"); ?>",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            beforeSend:function(){					
                $('#data-loading').html(data_loading);					 
            },
            success: function(result)
            { 
                $('#data-loading').html('');	
                if (result=='success') {
                    swal.fire({
						title: "Success!",
						text: "Data created !",
						icon: "success",
						button: "Ok",
					});
                }
                $('#exampleModal').modal('hide');
                // window.location.reload();
            },
            error: function() 
            {
                // window.location.reload();
            } 	        
        });
    })
</script>
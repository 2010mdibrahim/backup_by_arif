<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Task_list extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Dashboard_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->library('SSP');
		
	}


	public function task_create(){
		$data = array();
		$department = $_SESSION['user_info']['department'];
		date_default_timezone_set('Asia/Dhaka');
		$date_time = date('Y-m-d h:i:s a', time());
		$id_emp = $_SESSION['super_admin']['employee_ids'];

		$player = $this->db->query("SELECT player_id FROM employee WHERE department ='$department'");
		$player = $player->result();
		$player_ids = [];
		foreach ($player as $value) {
			$player_ids[] = $value->player_id;
		}

		if(!isset($_SESSION['super_admin']['email'])){
			redirect(base_url('admin/login'));
		} else {
			if (!empty($this->input->post('get_bouns_amount'))) {
				//========================================	
				$employee_row = $this->DB->mysqlr_array("SELECT employee_id,basic_salary from employee where employee_id = '".$this->input->post('employee_id')."'");
				$sallary_per_day = (float)$employee_row['basic_salary'];
				
				// add increament per day
				$check_increament = $this->DB->mysqlr_array("SELECT sum(amount) as total_inc from employee_increament_logs where employee_id = '" . $employee_row['employee_id'] . "' and aproval = '1' and start_date_modify <= '" . date('Ymd') . "'");
				if(!empty($check_increament['total_inc'])){
					$sallary_per_day = $sallary_per_day + $check_increament['total_inc'];
				}	
				
				// Remove decreament per day
				$check_decreament = $this->DB->mysqlr_array("SELECT sum(amount) as total_dec from employee_decreament_logs where employee_id = '" . $employee_row['employee_id'] . "' and aproval = '1' and start_date_modify <= '" . date('Ymd') . "'");
				if(!empty($check_decreament['total_dec'])){
					$sallary_per_day = $sallary_per_day - $check_decreament['total_dec'];
				}			
				//========================================
				echo ($sallary_per_day * $this->input->post('task_point')) / 100;
				exit;
			}

			/* Start creating task */
			if(isset($_POST['save'])){
				// gif|jpg|png|jpeg
				$this->form_validation->set_rules('title', 'title', 'trim|required');
				$this->form_validation->set_rules('description', 'description', 'trim|required');
				$config = array();
				$config['upload_path'] = './assets/uploads/task_list';
				$config['allowed_types'] = '*';
				$config['remove_spaces'] = TRUE;
				$config['encrypt_name'] = TRUE;
				$this->load->library('upload', $config);
				$title = addslashes($this->input->post('title'));
				$description = addslashes($this->input->post('description'));
				$task_benefit = addslashes($this->input->post('task_benefit'));
				$assigned_to = $this->input->post('employee_id') ? $this->input->post('employee_id') : '';
				$assigned_by = $_SESSION['super_admin']['employee_ids'];
				$rate = '5';
				$deadline =  $this->input->post('deadline');
				$have_point= 0;
				$task_type = 'regular';
				if ($this->input->post('bouns_type') == 'positive' && $this->input->post('regular_point') != 0) {
					$task_point = $this->input->post('regular_point');
					$have_point=1;
				}elseif ($this->input->post('bouns_type') == 'negative' && $this->input->post('regular_point') != 0) {
					$task_point = -1*floatval($this->input->post('regular_point')); 
					$have_point=1;
				}

				if (isset($task_point)) {
					$point_table_data = $this->db->query("SELECT SUM(task_point) AS total_task_point FROM task_point_table WHERE task_type='".$task_type."' AND employee_id='".$assigned_to."' AND approval=1 GROUP BY employee_id")->row();
					if (isset($point_table_data->total_task_point)) {
						$total_point = $point_table_data->total_task_point+$task_point;
					}else {
						$total_point = isset($task_point)?$task_point:0;
					}
				}
				

				$file_status =$this->upload->do_upload('image');
				$task_image = $this->upload->data('file_name');

				// assign person department id change whene data insert by top management
				if ($department==749568347163692080) {
					$data=$this->db->query("SELECT department FROM employee WHERE employee_id='$assigned_to'")->row();
					$department = $data->department;
				}

				if($this->form_validation->run() == FALSE){
					alert('danger','Something Wrong! Please try Again');
					redirect(current_url());
				}else{
					if ($file_status) {
						$insert = $this->db->query("INSERT into task_list (title,description,priority_rate,task_image,department_id,assigned_to,assigned_by,status,deadline_at,created_at,have_point,complete_by,completed_at) values ('$title','$description','$rate','$task_image','$department','$assigned_to','$assigned_by','$status','$deadline','$date_time','$have_point','$complete_by','$completed_at')");
						if($insert){
							$task_id = $this->db->insert_id();
							if (isset($task_point) && $task_point !=0) {
								$point_data = array(
									'task_id' => $task_id,
									'employee_id' => $assigned_to,
									'task_benefit' => $task_benefit,
									'task_type' => $task_type,
									'task_point' => $task_point,
									'total_point' => $total_point,
									'approval' => 0,
									'created_by' => $assigned_by,
									'created_at' => $date_time
								);
								$this->db->insert('task_point_table', $point_data);
							}

							// sending notification to mobile via api call
							if ($assigned_to !== '') {
								$xy=$this->Dashboard_model->onesignal('New Task Created in Your Department!', 'Task Notification', array("$assigned_to"));
							}else {
								$query=$this->Dashboard_model->mysqlij("SELECT player_id FROM employee WHERE department ='$department'");
								$xy=$this->Dashboard_model->onesignal('New Task Created in Your Department!', 'Task Notification', $player_ids);
							}
							alert('success','Save Successfully!');
							//redirect(current_url());
						}else{
							alert('danger','Something Wrong! Please try Again');
							redirect(current_url());
						}
					}elseif(!$file_status && !empty($task_image)) {
						alert('danger','Something Wrong! Please try Again');
						redirect(current_url());
					}else {
						$insert = $this->db->query("INSERT INTO task_list (title,description,priority_rate,department_id,assigned_to,assigned_by,status,deadline_at,created_at,have_point,complete_by,completed_at) VALUES ('$title','$description','$rate','$department','$assigned_to','$assigned_by','$status','$deadline','$date_time','$have_point','$complete_by','$completed_at')");
						
						if($insert){
							$task_id = $this->db->insert_id();
							if (!empty($task_point)) {
								$point_data = array(
									'task_id' => $task_id,
									'employee_id' => $assigned_to,
									'task_benefit' => $task_benefit,
									'task_type' => $task_type,
									'task_point' => $task_point,
									'total_point' => $total_point,
									'approval' => 0,
									'created_by' => $assigned_by,
									'created_at' => $date_time
								);
								$this->db->insert('task_point_table', $point_data);
							}
							
							// sending notification to mobile via api call
							if ($assigned_to !== '') {
								$xy=$this->Dashboard_model->onesignal('New Task Created in Your Department!', 'Task Notification', array("$assigned_to"));
							}else {
								$query=$this->Dashboard_model->mysqlij("SELECT player_id FROM employee WHERE department ='$department'");
								$xy=$this->Dashboard_model->onesignal('New Task Created in Your Department!', 'Task Notification', $player_ids);
							}
						alert('success','Save Successfully!');
						//redirect(current_url());
						}else{
							alert('danger','Something Wrong! Please try Again');
							redirect(current_url());
						}
					}

				}

				
			}

			if ((!empty($task_point) && $task_point < 0 && !empty($task_id)) OR (!empty($deadline) && $deadline < date("Y-m-d"))) {
				$auto_complete = array(
					'status' => 2,
					'processing_by' => $assigned_to,
					'complete_by' => $assigned_to,
					'accepted_at' => $date_time,
					'target_at' => $date_time,
					'completed_at' => $date_time,
				);
				$this->DB->update('task_list', $auto_complete, $task_id);
			}
			/* End creating task */
			
			
			/* Start creating task */
			if(!empty($this->input->post('save_multi_task'))){
				// gif|jpg|png|jpeg
				foreach ($this->input->post('title2') as $key => $title) {
					// $config = array();
					// $config['upload_path'] = './assets/uploads/task_list';
					// $config['allowed_types'] = '*';
					// $config['remove_spaces'] = TRUE;
					// $config['encrypt_name'] = TRUE;
					// $this->load->library('upload', $config);
					$title = addslashes($title);
					$description = addslashes($this->input->post('description2')[$key]);
					$task_benefit = '';
					$assigned_to = $this->input->post('employee_id2') ? $this->input->post('employee_id2') : '';
					$assigned_by = $_SESSION['super_admin']['employee_ids'];
					$rate = 5;
					$deadline =  '';
					$status = 0;
					$have_point= 0;
					$task_type = !empty($this->input->post('task_type2')[$key]) ? $this->input->post('task_type2')[$key] : '';
					if ($task_type=='regular' && $this->input->post('regular_point2')[$key] >0) {
						$task_point = $this->input->post('regular_point2')[$key];
						$have_point=1;
					}elseif ($task_type=='challenging' && $this->input->post('challeng_point2')[$key] >0) {
						$task_point = $this->input->post('challeng_point2')[$key];
						$have_point=1;
					} 

					if (isset($task_point)) {
						$point_table_data = $this->db->query("SELECT SUM(task_point) AS total_task_point FROM task_point_table WHERE task_type='".$task_type."' AND employee_id='".$assigned_to."' AND approval=1 GROUP BY employee_id")->row();
						if (isset($point_table_data->total_task_point)) {
							$total_point = $point_table_data->total_task_point+$task_point;
						}else {
							$total_point = isset($task_point)?$task_point:0;
						}
					}
					
					
					$file_name 		= $_FILES['image2']['name'][$key];
					$file_tmp 		= $_FILES['image2']['tmp_name'][$key];
					
					$file_status = move_uploaded_file($file_tmp, 'assets/uploads/task_list/' . $file_name);
					$task_image = $file_name;

					// assign person department id change whene data insert by top management
					if ($department==749568347163692080) {
						$data=$this->db->query("SELECT department FROM employee WHERE employee_id='$assigned_to'")->row();
						$department = $data->department;
					}

					if ($file_status) {
						$insert = $this->db->query("INSERT into task_list (title,description,priority_rate,task_image,department_id,assigned_to,assigned_by,status,deadline_at,created_at,have_point) values ('$title','$description','$rate','$task_image','$department','$assigned_to','$assigned_by','$status','$deadline','$date_time','$have_point')");
						if($insert){
							$task_id = $this->db->insert_id();
							if (!empty($task_type) && isset($task_point) && $task_point >0) {
								$point_data = array(
									'task_id' => $task_id,
									'employee_id' => $assigned_to,
									'task_benefit' => $task_benefit,
									'task_type' => $task_type,
									'task_point' => $task_point,
									'total_point' => $total_point,
									'approval' => 0,
									'created_by' => $assigned_by,
									'created_at' => $date_time
								);
								$this->db->insert('task_point_table', $point_data);
							}

							// sending notification to mobile via api call
							if ($assigned_to !== '') {
								$xy=$this->Dashboard_model->onesignal('New Task Created in Your Department!', 'Task Notification', array("$assigned_to"));
							}else {
								$query=$this->Dashboard_model->mysqlij("SELECT player_id FROM employee WHERE department ='$department'");
								$xy=$this->Dashboard_model->onesignal('New Task Created in Your Department!', 'Task Notification', $player_ids);
							}
							alert('success','Save Successfully!');
							//redirect(current_url());
						}else{
							alert('danger','Something Wrong! Please try Again');
							redirect(current_url());
						}
					}elseif(!$file_status && !empty($task_image)) {
						alert('danger','Something Wrong! Please try Again');
						redirect(current_url());
					}else {
						$insert = $this->db->query("INSERT INTO task_list (title,description,priority_rate,department_id,assigned_to,assigned_by,status,deadline_at,created_at,have_point) VALUES ('$title','$description','$rate','$department','$assigned_to','$assigned_by','$status','$deadline','$date_time',$have_point)");
						
						if($insert){
							$task_id = $this->db->insert_id();
							if (!empty($task_point)) {
								$point_data = array(
									'task_id' => $task_id,
									'employee_id' => $assigned_to,
									'task_benefit' => $task_benefit,
									'task_type' => $task_type,
									'task_point' => $task_point,
									'total_point' => $total_point,
									'approval' => 0,
									'created_by' => $assigned_by,
									'created_at' => $date_time
								);
								$this->db->insert('task_point_table', $point_data);
							}
							
							// sending notification to mobile via api call
							if ($assigned_to !== '') {
								$xy=$this->Dashboard_model->onesignal('New Task Created in Your Department!', 'Task Notification', array("$assigned_to"));
							}else {
								$query=$this->Dashboard_model->mysqlij("SELECT player_id FROM employee WHERE department ='$department'");
								$xy=$this->Dashboard_model->onesignal('New Task Created in Your Department!', 'Task Notification', $player_ids);
							}
						alert('success','Save Successfully!');
						//redirect(current_url());
						}else{
							alert('danger','Something Wrong! Please try Again');
							redirect(current_url());
						}
					}
				}
				/* End creating task */
			}
		}
	}


	public function task_update(){ 
		/* Start updating task */
		if(!isset($_SESSION['super_admin']['email'])){
			redirect(base_url('admin/login'));
		} else {
			$department = $_SESSION['user_info']['department'];
			$data = array();
			
			$this->form_validation->set_rules('title','title','trim|required');
			$this->form_validation->set_rules('description','description','trim|required'); 
			$config = array();
			$config['upload_path'] = './assets/uploads/task_list';
			$config['allowed_types'] = '*';
			$config['remove_spaces'] = TRUE;
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload', $config);
			$update_id = $this->input->post('update_id');
			$title = addslashes($this->input->post('title'));
			$description = addslashes($this->input->post('description'));
			$assigned_to = $this->input->post('employee_id') ? $this->input->post('employee_id') : '';
			$assigned_by = $_SESSION['super_admin']['employee_ids'];
			$status = 0;
			$file_status =$this->upload->do_upload('image');
			$task_image = $this->upload->data('file_name');
			$task_type = 'regular';
			$task_point = $this->input->post('edit_regular_point') ? $this->input->post('edit_regular_point') : '';
			$task_information = $this->db->query("SELECT * FROM task_list WHERE id='".$update_id."'")->row();

			if($this->form_validation->run() == FALSE){
				alert('danger','Something Wrong! Please try Again');
				redirect(current_url());
			}else{
				if ($file_status) {
					$update = $this->db->query("UPDATE task_list SET title='$title', description='$description',task_image='$task_image',assigned_to='$assigned_to' WHERE id='$update_id'");
					if($update){
						alert('success','Save Successfully!');
						//redirect(current_url());
					}else{
						alert('danger','Something Wrong! Please try Again');
						//redirect(current_url());
					}
				}elseif(!$file_status && !empty($task_image)) {
					alert('danger','Something Wrong! Please try Again');
					//redirect(current_url());
				}else {
					$update = $this->db->query("UPDATE task_list SET title='$title', description='$description',assigned_to='$assigned_to' WHERE id='$update_id'");
					if($update){
						alert('success','Update Successfully!');
						//redirect(current_url());
					}else{
						alert('danger','Something Wrong! Please try Again');
						//redirect(current_url());
					}
				}
				// update task point gainer
				if (isset($task_information->have_point) && $task_information->have_point==1 && !empty($assigned_to) && $update) {
					$d_head = $this->db->query("SELECT id FROM employee WHERE employee_id='".$assigned_to."' AND d_head=1")->row();
					if (!empty($d_head->id)) {
						$this->db->query("DELETE FROM task_point_table WHERE task_id='".$update_id."'");
						$this->db->query("UPDATE task_list SET have_point=0 WHERE id='$update_id'");
					}else {
						$this->db->query("UPDATE task_point_table SET employee_id='".$assigned_to."', task_point='".$task_point."' WHERE task_id='".$update_id."'");
					}
				}else {
					if (!empty($task_point)) {
						$point_table_data = $this->db->query("SELECT SUM(task_point) AS total_task_point FROM task_point_table WHERE task_type='".$task_type."' AND employee_id='".$assigned_to."' AND approval=1 GROUP BY employee_id")->row();
						if (isset($point_table_data->total_task_point)) {
							$total_point = $point_table_data->total_task_point+$task_point;
						}else {
							$total_point = isset($task_point)?$task_point:0;
						}
						
						$point_data = array(
							'task_id' => $update_id,
							'employee_id' => $assigned_to,
							'task_benefit' => '',
							'task_type' => $task_type,
							'task_point' => $task_point,
							'total_point' => $total_point,
							'approval' => 0,
							'created_by' => $assigned_by,
							'created_at' => date('Y-m-d h:i:s a', time())
						);
						$this->db->insert('task_point_table', $point_data);
					}
				}
				
			}
		}
		 /* End of upddating task */
	}

    public function Task_list_control(){ 
		if(!isset($_SESSION['super_admin']['email'])){
			redirect(base_url('admin/login'));
		} else {
			$data = array();
			$department = $_SESSION['user_info']['department'];
			date_default_timezone_set('Asia/Dhaka');
			$date_time = date('Y-m-d h:i:s a', time());
			$id_emp = $_SESSION['super_admin']['employee_ids'];

			$player = $this->db->query("SELECT player_id FROM employee WHERE department ='$department'");
			$player = $player->result();
			$player_ids = [];
			foreach ($player as $value) {
				$player_ids[] = $value->player_id;
			}

			if(isset($_POST['task_edit'])){
				$id = $this->input->post('task_edit');
				$sql = $this->db->query("SELECT employee_id, full_name, photo FROM employee WHERE d_head=1 AND status=1");
				$data['result'] = $sql->result();

				$query = $this->db->query("SELECT employee_id, full_name,d_head, photo FROM employee WHERE (department in ('$department', '749568347163692080') OR d_head='1') AND status = 1");
				
				$data['emp_list'] = $query->result();

				$data['dep_head'] = $this->db->query("SELECT d_head FROM employee WHERE  employee_id='$id_emp'")->row();
			
			 	$data['edit'] = $this->db->query("SELECT * FROM task_list WHERE id='$id'")->row();
			 	$data['edit_point'] = $this->db->query("SELECT * FROM task_point_table WHERE task_id='$id'")->row();
				$html = $this->load->view('template/tasks/edit_task',$data,TRUE);
				echo $html;
				exit;
			}

			
			
			if (isset($_POST['task_accept_id'])) {
			$emp_id = $_SESSION['super_admin']['employee_ids'];
			$task_id=$_POST['task_accept_id'];
			$url =base_url('admin/s_it/tasks');
			$date=date('Y-m-d');
			$time = date('H:i',strtotime('+59 min'));
				echo "<div class='text-center'>
					<form role='form' id='task_edit_form' action='$url' method='POST'>
						<input type='hidden' name='emp_id' value='$emp_id'/>
						<input type='hidden' name='task_id' value='$task_id'/>
						<label for='start'>When it will be done?</label>
						<br>
						<input type='date' id='start' name='task_end' min='$date' value='$date' required>
						<input type='time' id='time' name='time' value='$time' required>
						<br>
						<button type='button' id='accept' name='accept_task' data-task_id='$task_id' class='btn btn-warning mt-3'>Accept</button>
					</form>
				</div>";
			exit;
			}

			if (isset($_POST['send_to_pending_list'])) {
				if ($this->db->query("UPDATE task_list SET status='0' WHERE id='".$_POST['task_id']."'")) {
					
					$complainId = $this->db->query("SELECT complain_id FROM task_list WHERE id='".$_POST['task_id']."'")->row();
					if (!empty($complainId->complain_id)) {
						$data = array(
							'status' => 1,
							'ongoing_from' =>''
						);
						$ongoing = $this->db->where('id', $complainId->complain_id)->update('complain', $data);
					}
					echo 'success';
				}
				exit;
			}
			
			if(isset($_POST['task_complete_id'])){
				$task_id = $this->input->post('task_complete_id');
				
				$task_info = $this->db->query("SELECT id,title,description,task_image,processing_by,created_at FROM task_list WHERE id=$task_id");
				$data['task_info'] = $task_info->row();

				$html = $this->load->view('template/tasks/task_complete',$data,TRUE);
				echo $html;
				exit;
			}

			if (isset($_POST['review_form']) && !empty($this->input->post('task_id'))) {
				$task_id = $this->input->post('task_id');
				
				$task_info = $this->db->query("SELECT id,title,description,task_image,processing_by,created_at FROM task_list WHERE id=$task_id");
				$data['task_info'] = $task_info->row();
				
				$data['task_review'] = $this->db->query("SELECT *, (SELECT full_name FROM employee WHERE employee_id=created_by ) AS emp_name FROM task_review WHERE task_id='".$task_id."'")->result();
				$html = $this->load->view('template/tasks/send_review',$data,TRUE);
				echo $html;
				exit;
			}

			if (isset($_POST['review_submit'])) {
				$file_names='';
				for($i = 0; $i < count($_FILES['review_files']['name']); $i++){
					$file_name 	= $_FILES['review_files']['name'][$i];
					$file_tmp 	= $_FILES['review_files']['tmp_name'][$i];
					$temp 		= explode(".", $file_name);
					$file_name 	= uniqid('task') . '.' . end($temp);
					move_uploaded_file($file_tmp, "./assets/uploads/task_list" . $file_name);
					if (!empty($file_tmp)) {
						$file_names .= "./assets/uploads/task_list" . $file_name.",";
					}
				}
				$file_names 	= rtrim($file_names,",");
				$data = array(
					'task_id' => $this->input->post('task_id'),
					'feedback' => $this->input->post('description'),
					'task_files' => $file_names,
					'created_by' => $id_emp,
					'created_at' => $date_time
				);
				
				
				if ($this->db->insert('task_review', $data)) {
					echo "success";
					exit;
				}
			}

			if (isset($_POST['feedback_form']) && !empty($this->input->post('task_id'))) {
				$task_id = $this->input->post('task_id');
				
				$task_info = $this->db->query("SELECT id,title,description,task_image,processing_by,created_at FROM task_list WHERE id=$task_id");
				$data['task_info'] = $task_info->row();
				$data['task_point_info'] = $this->db->query("SELECT * FROM task_point_table WHERE task_id='".$task_id."'")->row();
				$data['task_review'] = $this->db->query("SELECT *, (SELECT full_name FROM employee WHERE employee_id=created_by ) AS emp_name FROM task_review WHERE task_id='".$task_id."'")->result();
				$html = $this->load->view('template/tasks/send_feedback',$data,TRUE);
				echo $html;
				exit;
			}
			
			if (!empty($this->input->post('get_task_employee_id'))) {
				$name = $this->input->post('emp_name');
				$result = $this->DB->mysqlr("SELECT employee_id FROM employee WHERE full_name like '%".$name."%'");
				echo $result->employee_id;
				exit;
			}

			if(!empty($this->input->post('pending-data-table'))){
				extract($_GET);
				$search_query = 'status=0';	
				$emp_id = $_SESSION['super_admin']['employee_ids'];
				
				// elseif ($_SESSION['super_admin']['user_type'] == 'Super Admin') {  
				// 	if ($_SESSION['user_info']['department'] == '749568347163692080') {
				// 		$search_query .='';
				// 	}else {
				// 		$search_query .= " AND department_id =".$_SESSION['user_info']['department'];
				// 	}
				// }
				if (!empty($this->input->get('departments')) || !empty($this->input->get('employee')) || !empty($this->input->get('date'))) {
					$search_query .='';
				}elseif ($_SESSION['user_info']['d_head'] == '1') {  
					$search_query .= " AND (department_id ='".$_SESSION['user_info']['department']."' OR assigned_to = '". $emp_id ."')";
				}else{
					$search_query .= " AND (assigned_to = '". $emp_id ."' OR assigned_by = '". $emp_id ."' OR (complain_id IS NOT NULL) AND department_id ='".$_SESSION['user_info']['department']."')";
				}	

				if (isset($departments) && !empty($departments)) {
					if ($departments == 'all') {
						$search_query .='';
					}else {
						$search_query .= " AND department_id = '".$departments."'";
					}
				}
				if (isset($employee) && !empty($employee)) {
					$search_query .= " AND (assigned_to = '".$employee."' OR assigned_by = '".$employee."')";
				}

				if (isset($date) && !empty($date) && ($_SESSION['user_info']['d_head'] == '1' || $_SESSION['super_admin']['user_type'] == 'Super Admin')) {
					$search_query .= " AND DATE_FORMAT(created_at, '%Y-%m') = '".$date."'";
				}elseif (isset($date) && !empty($date)) {
					$search_query .= " AND department_id ='".$_SESSION['user_info']['department']."' AND DATE_FORMAT(created_at, '%Y-%m') = '".$date."'";
				}

				$table = 'task_list';
				$primaryKey = 'id';
				$where = $search_query;
				
				$columns = array(
					array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) {
						$task_id = $d;
						$task_info = $this->db->query(" SELECT *,
							(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.assigned_by ) AS emp_name_by, 
							(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.assigned_to ) AS emp_name_to, 
							(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.processing_by ) AS emp_name_pro, 
							(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.complete_by ) AS emp_name_com 
						
						FROM task_list WHERE task_list.id=$task_id");
						$data['task_info'] = $task_info->row();
						if (!empty($data['task_info']->assigned_to)) {
							$employee_info = $this->DB->mysqlr("SELECT photo,full_name FROM employee WHERE employee_id='".$data['task_info']->assigned_to."'");
						}else{
							$employee_info = $this->DB->mysqlr("SELECT photo,full_name FROM employee WHERE employee_id='".$data['task_info']->assigned_by."'");
						}
						$result=$this->db->query("SELECT task_comment.id, task_id, comment, created_at, full_name FROM task_comment, employee WHERE task_id='$task_id' AND task_comment.employee_id = employee.employee_id ORDER BY task_comment.id DESC LIMIT 3");
						$data['comment']= $result->result();
						if (isset($_POST['get_point_form'])) {
							$data['task_point_data'] = $this->db->query("SELECT task_point_table.*,task_list.title FROM task_point_table, task_list WHERE task_id='".$task_id."' AND task_point_table.task_id=task_list.id")->row();
						}
						$data['task_priority']= '<span class="fa fa-star '.($data['task_info']->priority_rate > 0 ? 'checked' : '') .'"></span>
					 			<span class="fa fa-star '.($data['task_info']->priority_rate > 1 ? 'checked' : '') .'"></span>
					 			<span class="fa fa-star '.($data['task_info']->priority_rate > 2 ? 'checked' : '') .'"></span>
					 			<span class="fa fa-star '.($data['task_info']->priority_rate > 3 ? 'checked' : '') .'"></span>
					 			<span class="fa fa-star '.($data['task_info']->priority_rate > 4 ? 'checked' : '') .'"></span>';
						
						$data['editButton'] ='';
						if ($data['task_info']->assigned_by==$_SESSION['super_admin']['employee_ids'] || $_SESSION['user_info']['d_head']=='1') {
							$data['editButton'] = '<button href="#" data-task_edit="'.$d.'" class="btn btn-xs btn-primary task_edit" data-toggle="modal" data-target="#exampleModal2"><i class="fa fa-edit" style="font-size:18px;"></i> Edit</button>';
						}
						$html = $this->load->view('template/tasks/task_detail_page',$data,TRUE);
						return '<div class="row">
									<div class="col-1">
										<img style="border-radius: 50%;width:50px; height:50px;" src="'.base_url($employee_info->photo).'" alt="Pic">
									</div>
									<div class="col-11">
										<h3 class="card-title font-weight-bold" style="margin-left: 20px;">'.$employee_info->full_name.'</h3>
										<div class="container">
											<div class="arrow">
											<div class="outer"></div>
											<div class="inner"></div>
											</div>
											<div class="message-body">'.$html.'</div>
										</div>
									</div>
								</div>';
						// return $d.'<input type="hidden" class="colorClass" value="'.( $row[3]==$_SESSION['super_admin']['employee_ids']? 1 : 0 ).'">';
					}),
				);			
				echo json_encode( SSP::complex( $_POST, array( 'user' => db_info()['user'], 'pass' => db_info()['pass'], 'db'   => db_info()['db'], 'host' => db_info()['host'] ), $table, $primaryKey, $columns , $where , null) );
				exit();
			}

			if(!empty($this->input->post('processing-data-table'))){
				extract($_GET);
				$search_query = 'status=1';	
				$emp_id = $_SESSION['super_admin']['employee_ids'];
				
				// elseif ($_SESSION['super_admin']['user_type'] == 'Super Admin') {  
				// 	if ($_SESSION['user_info']['department'] == '749568347163692080') {
				// 		$search_query .='';
				// 	}else {
				// 		$search_query .= " AND department_id =".$_SESSION['user_info']['department'];
				// 	}
				// }
				if (!empty($this->input->get('departments')) || !empty($this->input->get('employee')) || !empty($this->input->get('date'))) {
					$search_query .='';
				}elseif ($_SESSION['user_info']['d_head'] == '1') {  
					$search_query .= "  AND (department_id ='".$_SESSION['user_info']['department']."' OR processing_by = '". $emp_id ."')";
				}else{
					$search_query .= " AND (processing_by = '". $emp_id ."' OR assigned_by = '". $emp_id ."')";
				}
					
				if (isset($departments) && !empty($departments)) {
					if ($departments == 'all') {
						$search_query .='';
					}else {
						$search_query .= " AND department_id = '".$departments."'";
					}
				}
				if (isset($employee) && !empty($employee)) {
					$search_query .= " AND (processing_by = '".$employee."' OR assigned_by = '". $employee ."')";
				}
				if (isset($date) && !empty($date) && ($_SESSION['user_info']['d_head'] == '1' || $_SESSION['super_admin']['user_type'] == 'Super Admin')) {
					$search_query .= " AND DATE_FORMAT(created_at, '%Y-%m') = '".$date."'";
				}elseif (isset($date) && !empty($date)) {
					$search_query .= " AND department_id ='".$_SESSION['user_info']['department']."' AND DATE_FORMAT(created_at, '%Y-%m') = '".$date."'";
				}

				$table = 'task_list';
				$primaryKey = 'id';
				$where = $search_query;
				
				$columns = array(
					array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) {
						$task_id = $d;
						$task_info = $this->db->query(" SELECT *,
							(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.assigned_by ) AS emp_name_by, 
							(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.assigned_to ) AS emp_name_to, 
							(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.processing_by ) AS emp_name_pro, 
							(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.complete_by ) AS emp_name_com 
						
						FROM task_list WHERE task_list.id=$task_id");
						$data['task_info'] = $task_info->row();
						$employee_info = $this->DB->mysqlr("SELECT photo,full_name FROM employee WHERE employee_id='".$data['task_info']->processing_by."'");
						
						$result=$this->db->query("SELECT task_comment.id, task_id, comment, created_at, full_name FROM task_comment, employee WHERE task_id='$task_id' AND task_comment.employee_id = employee.employee_id ORDER BY task_comment.id DESC LIMIT 3");
						$data['comment']= $result->result();
						if (isset($_POST['get_point_form'])) {
							$data['task_point_data'] = $this->db->query("SELECT task_point_table.*,task_list.title FROM task_point_table, task_list WHERE task_id='".$task_id."' AND task_point_table.task_id=task_list.id")->row();
						}
						$data['task_complete_status'] = 0;
						$data['task_target'] = '<span class="demo" data-val="'.$data['task_info']->target_at.'">'.$data['task_info']->target_at.'</span>';					
						$data['pro_buttons']='';
						if ($data['task_info']->processing_by==$_SESSION['super_admin']['employee_ids']) {
							$data['pro_buttons'] .='<button class="btn btn-xs btn-info" onclick="reviewModal('. $d .')" data-toggle="tooltip" data-placement="top" title="Send for review"><i class="fas fa-file-export"></i></button>';
						}
						if ($data['task_info']->processing_by==$_SESSION['super_admin']['employee_ids']) {
							$data['pro_buttons'] .='<button class="btn btn-xs btn-warning" onclick="backToPending('. $d .')" data-toggle="tooltip" data-placement="top" title="Back to pending"><i class="fas fa-backward"></i></button>';
						}
						$taskReview = $this->db->query("SELECT id FROM task_review WHERE task_id='".$d."'")->num_rows();
						if ($taskReview>0) {
							$data['onReview'] = '<span class="badge badge-pill badge-danger">On Review</span>';
						}else {
							$data['onReview'] ='';
						}

						$html = $this->load->view('template/tasks/task_detail_page',$data,TRUE);
						return '<div class="row">
									<div class="col-1">
										<img style="border-radius: 50%;width:50px; height:50px;" src="'.base_url($employee_info->photo).'" alt="Pic">
									</div>
									<div class="col-11">
										<h3 class="card-title font-weight-bold" style="margin-left: 20px;">'.$employee_info->full_name.'</h3>
										<div class="container">
											<div class="arrow">
											<div class="outer"></div>
											<div class="inner"></div>
											</div>
											<div class="message-body">'.$html.'</div>
										</div>
									</div>
								</div>';
						// return $d.'<input type="hidden" class="colorClass" value="'.( $row[3]==$_SESSION['super_admin']['employee_ids']? 1 : 0 ).'">';
					}),
				);			
				echo json_encode( SSP::complex( $_POST, array( 'user' => db_info()['user'], 'pass' => db_info()['pass'], 'db'   => db_info()['db'], 'host' => db_info()['host'] ), $table, $primaryKey, $columns , $where , null) );
				exit();
			}

			if(!empty($this->input->post('complete-data-table'))){
				extract($_GET);
				$search_query = 'status=2';	
				$emp_id = $_SESSION['super_admin']['employee_ids'];
				
				// elseif ($_SESSION['super_admin']['user_type'] == 'Super Admin') {  
				// 	if ($_SESSION['user_info']['department'] == '749568347163692080') {
				// 		$search_query .='';
				// 	}else {
				// 		$search_query .= " AND department_id =".$_SESSION['user_info']['department'];
				// 	}
				// }
				if (!empty($this->input->get('departments')) || !empty($this->input->get('employee')) || !empty($this->input->get('date'))) {
					$search_query .='';
				}elseif ($_SESSION['user_info']['d_head'] == '1') {  
					$search_query .= " AND (department_id ='".$_SESSION['user_info']['department']."' OR complete_by = '". $emp_id ."')";
				}else{
					$search_query .= " AND (complete_by = '". $emp_id ."' OR assigned_by = '". $emp_id ."')";
				}
				
				if (isset($departments) && !empty($departments)) {
					if ($departments == 'all') {
						$search_query .='';
					}else {
						$search_query .= " AND department_id = '".$departments."'";
					}
				}
				if (isset($employee) && !empty($employee)) {
					$search_query .= " AND (complete_by = '".$employee."' OR assigned_by = '". $emp_id ."')";
				}	
				if (isset($date) && !empty($date) && ($_SESSION['user_info']['d_head'] == '1' || $_SESSION['super_admin']['user_type'] == 'Super Admin')) {
					$search_query .= " AND DATE_FORMAT(completed_at, '%Y-%m') = '".$date."'";
				}elseif (isset($date) && !empty($date)) {
					$search_query .= " AND department_id ='".$_SESSION['user_info']['department']."' AND DATE_FORMAT(completed_at, '%Y-%m') = '".$date."'";
				}

				$table = 'task_list';
				$primaryKey = 'id';
				$where = $search_query;
				
				$columns = array(
					array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) {
						$status = $comment_datum = $image = $datum = '';
						$task_info = $this->DB->mysqlr("SELECT * FROM task_list WHERE id='".$d."'");
						$employee_info = $this->DB->mysqlr("SELECT photo,full_name FROM employee WHERE employee_id='".$task_info->complete_by."'");
						$comment = $this->DB->mysqli("SELECT *,(SELECT full_name FROM employee WHERE employee.employee_id=task_comment.employee_id) AS fullname FROM task_comment WHERE task_id='".$task_info->id."' ORDER BY id DESC");
						if(!empty($task_info->accepted_at)){
							$phpdate = strtotime( $task_info->accepted_at );
							$mysqldate = date( 'd M Y h:i A', $phpdate );
						}
						if(!empty($task_info->completed_at)){
							$phpdate = strtotime( $task_info->completed_at );
							$mysqldate2 = date( 'd M Y h:i A', $phpdate );
						}
						
						switch ($task_info->status) {
							case "1":
								$status = 'Processing';
								break;
							case "2":
								$status = 'Completed';
								break;
							default:
							$status = 'Queue';
						}
						foreach($comment as $data) {
							$phpdate = strtotime( $data->created_at );
							$mysqldate = date( 'd M Y, h:i A', $phpdate );
							$comment_datum .="<div class='d-flex flex-row mt-3'>
												<h2 class='col-2 text-right'>
													<i class='far fa-user-circle pt-1 text-info'></i>
												</h2>
												<div class='col-10'>
													<p class='font-weight-bold'>$data->fullname <small class='text-muted' style='font-size:11px'>$mysqldate</small></p>
													<p>$data->comment</p>
												</div>
											</div>";
						}
						if (!empty($task_info->task_image)) {
							$image = '<img src="'.base_url('assets/uploads/task_list/').$task_info->task_image.'" class="card-img-top" style="max-height: 400px">';
						}

						$mem_info ='';
						if (!empty($task_info->complain_id)) {
							$member_info = $this->db->query("SELECT * FROM member_directory WHERE id IN (SELECT member_directory_id FROM complain WHERE id='".$task_info->complain_id."')")->row();
							if (!empty($member_info)) {
								$mem_info= '<fieldset class="border p-2">
									<legend class="w-auto m-0 text-primary" style="font-size:14px;">Member Info:</b></legend>
									<b>Name: </b>'. $member_info->full_name .',
									<b>Phone: </b>'. $member_info->phone_number .',
									<b>Branch: </b>'. $member_info->branch_name .',
									<b>Floor: </b>'. $member_info->floor_name .',
									<b>Room: </b>'. $member_info->room_name .',
									<b>Bed: </b>'. $member_info->bed_name .'
								</fieldset>';
							}
						}

						$datum = '<div class="card mb-3" style="white-space: normal;">
										'.$image.'
										<div class="card-header text-muted">
											<small>'.(!empty($task_info->emp_name_by) ? " Assigned by: $task_info->emp_name_by," : "") .'</small>
											<small>'.(!empty($task_info->emp_name_to) ? " Assigned to: $task_info->emp_name_to," : "").'</small>
											<small>'.(!empty($task_info->emp_name_pro) ? " Processing By: $task_info->emp_name_pro," : "").'</small>
											<small>'.(!empty($task_info->emp_name_com) ? " Complete By: $task_info->emp_name_com," : "").'</small>
											<small>'.(!empty($task_info->accepted_at) ? " Accepted at: $mysqldate," : "").'</small>
											<small>'.(!empty($task_info->completed_at) ? " Completed at: $mysqldate2," : "").'</small>
											<small>Status:'.$status.'</small>
											'.$mem_info.'
										</div>
										<div class="card-body">
											<h6 >Title: '.$task_info->title.'</h6>
											<p class="card-text">Detail: '.find_link($task_info->description).'</p>
											<p class="card-text"><small class="text-muted">'.$task_info->created_at.'</small></p>
										</div>
										<div class="card-footer">'.$comment_datum.'</div>
									</div>';
								
								
						return '<div class="row">
									<div class="col-1">
										<img style="border-radius: 50%;width:50px; height:50px;" src="'.base_url($employee_info->photo).'" alt="Pic">
									</div>
									<div class="col-11">
										<h3 class="card-title font-weight-bold" style="margin-left: 20px;">'.$employee_info->full_name.'</h3>
										<div class="container">
											<div class="arrow">
											<div class="outer"></div>
											<div class="inner"></div>
											</div>
											<div class="message-body">'.$datum.'</div>
										</div>
									</div>
								</div>';
					}),
				);			
				echo json_encode( SSP::complex( $_POST, array( 'user' => db_info()['user'], 'pass' => db_info()['pass'], 'db'   => db_info()['db'], 'host' => db_info()['host'] ), $table, $primaryKey, $columns , $where , null) );
				exit();
			}

			if(!empty($this->input->post('review-data-table'))){
				extract($_GET);
				$search_query = 'status=1 AND id IN (SELECT task_id FROM task_review)';	
				$emp_id = $_SESSION['super_admin']['employee_ids'];
				
				// elseif ($_SESSION['super_admin']['user_type'] == 'Super Admin') { 
				// 	if ($_SESSION['user_info']['department'] == '749568347163692080') {
				// 		$search_query .='';
				// 	}else {
				// 		$search_query .= " AND department_id =".$_SESSION['user_info']['department'];
				// 	}
				// }
				if (!empty($this->input->get('departments')) || !empty($this->input->get('employee')) || !empty($this->input->get('date'))) {
					$search_query .='';
				}elseif ($_SESSION['user_info']['d_head'] == '1') {  
					$search_query .= " AND department_id =".$_SESSION['user_info']['department'];
				}else{
					$search_query .= " AND (processing_by = '". $emp_id ."' OR assigned_by = '". $emp_id ."')";
				}	

				if (isset($departments) && !empty($departments)) {
					$search_query .= " AND department_id = '".$departments."'";
				}
				if (isset($employee) && !empty($employee)) {
					$search_query .= " AND (processing_by = '".$employee."'  OR assigned_by = '". $employee ."')";
				}	
				if (isset($date) && !empty($date) && ($_SESSION['user_info']['d_head'] == '1' || $_SESSION['super_admin']['user_type'] == 'Super Admin')) {
					$search_query .= " AND DATE_FORMAT(created_at, '%Y-%m') = '".$date."'";
				}elseif (isset($date) && !empty($date)) {
					$search_query .= " AND department_id ='".$_SESSION['user_info']['department']."' AND DATE_FORMAT(created_at, '%Y-%m') = '".$date."'";
				}

				$table = 'task_list';
				$primaryKey = 'id';
				$where = $search_query;
				
				$columns = array(
					array( 'db' => 'id', 'dt' => 0, 'formatter'=>function( $d, $row ){
						$task_id = $d;
				
						$task_info = $this->db->query("SELECT id,title,description,task_image,processing_by,created_at FROM task_list WHERE id=$task_id");
						$data['task_info'] = $task_info->row();
						$employee_info = $this->DB->mysqlr("SELECT photo,full_name FROM employee WHERE employee_id='".$data['task_info']->processing_by."'");
						$data['task_point_info'] = $this->db->query("SELECT * FROM task_point_table WHERE task_id='".$task_id."'")->row();
						$data['task_review'] = $this->db->query("SELECT *, (SELECT full_name FROM employee WHERE employee_id=created_by ) AS emp_name FROM task_review WHERE task_id='".$task_id."'")->result();
						$html = $this->load->view('template/tasks/send_feedback',$data,TRUE);
						return '<div class="row">
									<div class="col-1">
										<img style="border-radius: 50%;width:50px; height:50px;" src="'.base_url($employee_info->photo).'" alt="Pic">
									</div>
									<div class="col-11">
										<h3 class="card-title font-weight-bold" style="margin-left: 20px;">'.$employee_info->full_name.'</h3>
										<div class="container">
											<div class="arrow">
											<div class="outer"></div>
											<div class="inner"></div>
											</div>
											<div class="message-body">'.$html.'</div>
										</div>
									</div>
								</div>';
					}),
				);			
				echo json_encode( SSP::complex( $_POST, array( 'user' => db_info()['user'], 'pass' => db_info()['pass'], 'db'   => db_info()['db'], 'host' => db_info()['host'] ), $table, $primaryKey, $columns , $where , null) );
				exit();
			}

			$sql = $this->db->query("SELECT employee_id , full_name, photo FROM employee WHERE d_head =1 AND status =1");
			$data['result'] = $sql->result();

			$query = $this->db->query("SELECT employee_id, full_name,d_head, photo FROM employee WHERE (department = '".$department."' OR d_head='1') AND status = 1");
			$data['emp_list'] = $query->result();
			if ($_SESSION['user_info']['department'] == '749568347163692080') {
				$data['employee_info'] = $this->DB->mysqli("SELECT * FROM employee WHERE status=1");
			}else{
				$data['employee_info'] = $this->DB->mysqli("SELECT * FROM employee WHERE status=1 AND department ='".$_SESSION['user_info']['department']."'");
			}
			$data['dep_head'] 			= $this->db->query("SELECT d_head FROM employee WHERE  employee_id='$id_emp'")->row();
			$data['department_info'] 	= $this->DB->mysqli("SELECT * FROM department WHERE status=1");
			$data['title_info'] 		= 'TODO List'; 
			$data['header'] 			= $this->load->view('include/header','',TRUE); 
			$data['nav'] 				= $this->load->view('include/nav','',TRUE); 
			$data['article'] 			= $this->load->view('template/tasks/task_list_page',$data,TRUE); 
			$data['footer'] 			= $this->load->view('include/footer','',TRUE); 
			$this->load->view('dashboard',$data);
		}
    }

	public function task_accept(){
			$data = array();
			$task_id = $this->input->post('task_id');
			$task_end = $this->input->post('task_end');
			$time = $this->input->post('time');
			$taskInfo = $this->db->query("SELECT * FROM task_list WHERE id='".$task_id."'")->row();
			$department = $_SESSION['user_info']['department'];
			$emp_id = !empty($taskInfo->assigned_to) ? $taskInfo->assigned_to :  $this->input->post('emp_id');
			$d = $task_end." ".$time;
			$d = strtotime($d);
			$target_at = date("Y-m-d H:i:s", $d);
			$date_time = date('Y-m-d h:i:s a', time());
			$accept = $this->db->query("UPDATE task_list SET processing_by='".$emp_id."',accepted_at='".$date_time."', target_at='".$target_at."', status='1' WHERE id='".$task_id."'");

			if (!empty($taskInfo->complain_id)) {
				$data = array(
					'status' => 2,
					'ongoing_from' => time()
				);
				$ongoing = $this->db->where('id', $taskInfo->complain_id)->update('complain', $data);
			}
			//echo json_encode(array('html' => $this->load->view('template/tasks/processing_task',$data)));
			if($accept){ //
				echo 'success';
			}else{
				 echo "fail";
				 //redirect(current_url());
			}
	}

	public function complete_task(){
			$data = array();
			$department = $_SESSION['user_info']['department'];
			$emp_id = $this->input->post('emp_id');
			$task_id = $this->input->post('task_id');
			$date_time = date('Y-m-d h:i:s a', time());
			if (isset($_POST['task_point']) && !empty($_POST['task_point'])) {
				if ($this->db->query("UPDATE task_point_table SET task_point='".$_POST['task_point']."' WHERE task_id='".$task_id."'")) {
					$accept = $this->db->query("UPDATE task_list SET complete_by='$emp_id', status='2', completed_at='$date_time' WHERE id=$task_id");
				}
			}else{
				$accept = $this->db->query("UPDATE task_list SET complete_by='$emp_id', status='2', completed_at='$date_time' WHERE id=$task_id");
			}

			$complainId = $this->db->query("SELECT complain_id FROM task_list WHERE id='".$task_id."'")->row();
			if (!empty($complainId->complain_id)) {
				$data = array(
					'status' => 0,
					'finished_at' => time()
				);
				$ongoing = $this->db->where('id', $complainId->complain_id)->update('complain', $data);
			}

			if($accept){ //
				echo 'success';
			}else{
				 echo "fail";
				 //redirect(current_url());
			}
		// }
	}

	public function Task_detail_control()
	{
		if (isset($_POST['approve_task_point'])) {
			$curr_total_point = $_POST['total_point']+$_POST['task_point'];
			if ($this->db->query("UPDATE task_point_table SET task_point='".$_POST['task_point']."', total_point='".$curr_total_point."',assignee_point='".$_POST['assignee_point']."', approval=1, approval_date='".date('Y-m-d')."', approval_date_filter='".date('Ymd')."' WHERE task_id='".$_POST['task_id']."'")) {
				if ($this->db->query("UPDATE task_list SET have_point=0 WHERE id='".$_POST['task_id']."'")) {
					echo 'success';
				}
			}
			exit;
		}
		if (isset($_POST['reject_task_point'])) {
			if ($this->db->query("UPDATE task_point_table SET approval=2, approval_date='".date('Y-m-d')."', approval_date_filter='".date('Ymd')."' WHERE task_id='".$_POST['task_id']."'")) {
				if ($this->db->query("UPDATE task_list SET have_point=0 WHERE id='".$_POST['task_id']."'")) {
					echo 'success';
				}
			}
			exit;
		}

		$task_id = $this->input->post("task_info");
		
		$task_info = $this->db->query(" SELECT *,
			(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.assigned_by ) AS emp_name_by, 
			(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.assigned_to ) AS emp_name_to, 
			(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.processing_by ) AS emp_name_pro, 
			(SELECT employee.full_name FROM employee WHERE employee.employee_id=task_list.complete_by ) AS emp_name_com 
		
		FROM task_list WHERE task_list.id=$task_id");
		$data['task_info'] = $task_info->row();
		$result=$this->db->query("SELECT task_comment.id, task_id, comment, created_at, full_name FROM task_comment, employee WHERE task_id='$task_id' AND task_comment.employee_id = employee.employee_id ORDER BY task_comment.id DESC LIMIT 3");
		$data['comment']= $result->result();
		if (isset($_POST['get_point_form'])) {
			$data['task_point_data'] = $this->db->query("SELECT task_point_table.*,task_list.title FROM task_point_table, task_list WHERE task_id='".$task_id."' AND task_point_table.task_id=task_list.id")->row();
		}
		$html = $this->load->view('template/tasks/task_detail_page',$data,TRUE);
		echo $html;
	}

	public function comment()
	{
		if(isset($_POST['comment']))
		{
			$task_id= $this->input->post('task_id');
			$emp_id= $_SESSION['super_admin']['employee_ids'];
			$comment= $this->input->post('comment');
			if (!empty($comment)) {
				$insert= $this->db->query("INSERT INTO task_comment (task_id,employee_id,comment) VALUES ('$task_id','$emp_id','$comment')");
			}

			if (isset($insert) && $insert) {
				$result=$this->db->query("SELECT task_comment.id, task_id, comment, created_at, full_name FROM task_comment, employee WHERE task_id='$task_id' AND task_comment.employee_id = employee.employee_id ORDER BY task_comment.id DESC LIMIT 3");
				$comment= $result->row();
				$phpdate = strtotime( $comment->created_at );
				$mysqldate = date( 'd M Y, h:i A', $phpdate );
				echo "<div class='d-flex flex-row mt-3'>
						<h2 class='col-2 text-right'>
							<i class='far fa-user-circle pt-1 pr-2 text-info'></i>
						</h2>
						<div class=''>
							<h5>$comment->full_name <small class='text-muted' style='font-size:11px'>$mysqldate</small></h5>
							<p>$comment->comment</p>
						</div>
					</div>";
			}
		}

		if (!empty($_POST['count']) && !empty($_POST['task_id'])) {
			$count=$_POST['count'];
			$task_id=$_POST['task_id'];
			$row=$this->db->query("SELECT task_comment.id, task_id, comment, created_at, full_name FROM task_comment, employee WHERE task_id='$task_id' AND task_comment.employee_id = employee.employee_id ORDER BY task_comment.id DESC LIMIT 3,$count");
			$comment= $row->result();
			foreach ($comment as $data) {
			  $phpdate = strtotime( $data->created_at );
			  $mysqldate = date( 'd M Y, h:i A', $phpdate );
			echo "<div class='d-flex flex-row mt-3'>
					<h2 class='col-2 text-right'>
						<i class='far fa-user-circle pt-1 pr-2 text-info'></i>
					</h2>
					<div class=''>
						<h5>$data->full_name <small class='text-muted' style='font-size:11px'>$mysqldate</small></h5>
						<p>$data->comment</p>
					</div>
				</div>";
			}
		}
	}

	public function task_point_approval()
	{
		$data = array();
		if(!isset($_SESSION['super_admin']['email'])){
			redirect(base_url('admin/login'));
		} else {
			if(!empty($this->input->post('complete-data-table'))){
				extract($_GET);
				$search_query = 'status=2';	// AND have_point=1
				$emp_id = $_SESSION['super_admin']['employee_ids'];
				
				if ($_SESSION['super_admin']['user_type'] == 'Super Admin') { 
					$search_query .= " AND complete_by IN (SELECT employee_id FROM employee WHERE status=1)";
				}elseif($_SESSION['user_info']['d_head']==1){
					$search_query .= " AND department_id='".$_SESSION['user_info']['department']."'";
				}else{
					$search_query .= " AND (complete_by = '". $emp_id ."' OR assigned_by = '". $emp_id ."')";
				}
				
				if (isset($employee) && !empty($employee)) {
					$search_query .= " AND complete_by = '".$employee."'";
				}	
				if (isset($departments) && !empty($departments)) {
					if ($departments == 'all') {
						$search_query .='';
					}else {
						$search_query .= " AND department_id = '".$departments."'";
					}
				}
				if (isset($date) && !empty($date)) {
					$search_query .= " AND DATE_FORMAT(completed_at, '%Y-%m') = '".$date."'";
				}

				if ($_POST['approval_status']=='pending') {
					$search_query .= " AND have_point=1 AND id IN (SELECT task_id FROM `task_point_table` WHERE approval = 0)";
				}elseif ($_POST['approval_status']=='approved') {
					$search_query .= " AND id IN (SELECT task_id FROM `task_point_table` WHERE approval = 1)";
				}elseif ($_POST['approval_status']=='rejected') {
					$search_query .= " AND id IN (SELECT task_id FROM `task_point_table` WHERE approval = 2)";
				}

				$table = 'task_list';
				$primaryKey = 'id';
				$where = $search_query;
				
				$columns = array(
					array( 'db' => 'id', 'dt' => 0),
					array( 'db' => 'complete_by', 'dt' => 1, 'formatter' => function( $d, $row ) {
						$emp = $this->DB->mysqlr("SELECT photo from employee WHERE employee_id='".$d."'");
						return '<img src="'.base_url($emp->photo).'" alt="Profile pic" style="width: 40px; height: 40px;">';

					}),
					array( 'db' => 'complete_by', 'dt' => 2, 'formatter' => function( $d, $row ) {
						$emp = $this->DB->mysqlr("SELECT full_name,department_name from employee WHERE employee_id='".$d."'");
						return !empty($emp->full_name)? $emp->full_name :'';
					}),
					array( 'db' => 'complete_by', 'dt' => 3, 'formatter' => function( $d, $row ) {
						$emp = $this->DB->mysqlr("SELECT full_name,department_name from employee WHERE employee_id='".$d."'");
						return !empty($emp->department_name)? " <span class='text-primary'>$emp->department_name</span>" :'';
					}),
					array( 'db' => 'title', 'dt' => 4, 'formatter' => function( $d, $row ) {
						return '<span class="d-inline-block text-truncate" style="max-width: 800px;" data-toggle="tooltip" data-placement="top" title="'.$d.'" onclick="copyToClipboard(\''.$d.'\',this)">'.$d.'</span><button class="btn btn-xs text-primary mb-2" id="point_button_'.$d.'" onclick="pointForm('.$row[0].')" ><i class="fas fa-eye"></i></button>';

					}),
					array( 'db' => 'id', 'dt' => 5, 'formatter' => function( $d, $row ) {
						
						//========================================	
						$employee_row = $this->DB->mysqlr_array("SELECT employee_id,basic_salary from employee where employee_id = '".$row[1]."'");
						$sallary_per_day = (float)$employee_row['basic_salary'];
						
						// add increament per day
						$check_increament = $this->DB->mysqlr_array("SELECT sum(amount) as total_inc from employee_increament_logs where employee_id = '" . $employee_row['employee_id'] . "' and aproval = '1' and start_date_modify <= '" . date('Ymd') . "'");
						if(!empty($check_increament['total_inc'])){
							$sallary_per_day = $sallary_per_day + $check_increament['total_inc'];
						}	
						
						// Remove decreament per day
						$check_decreament = $this->DB->mysqlr_array("SELECT sum(amount) as total_dec from employee_decreament_logs where employee_id = '" . $employee_row['employee_id'] . "' and aproval = '1' and start_date_modify <= '" . date('Ymd') . "'");
						if(!empty($check_decreament['total_dec'])){
							$sallary_per_day = $sallary_per_day - $check_decreament['total_dec'];
						}			
						//========================================

						$task_point = $this->db->query("SELECT task_point_table.*,task_list.title FROM task_point_table, task_list WHERE task_id='".$d."' AND task_point_table.task_id=task_list.id")->row();
						// this.value = !!this.value && Math.abs(this.value) >= 0 ? Math.abs(this.value) : null;
						$input = '<input type="number" step="2" id="task_point_'.$row[0].'" oninput="bonus_calc(this,\''.$row[0].'\',\'emp\')" value="'.$task_point->task_point.'">';
						$input .= '<span id="performance_bonus_'.$row[0].'" class="ml-1">'.(money_f(($sallary_per_day * $task_point->task_point) / 100)).'</span>';
						$input .= '<input type="hidden" id="sallary_per_day_'.$row[0].'" value="'.$sallary_per_day.'">';
						$input .= '<input type="hidden" id="total_point_'.$row[0].'" value="'.($task_point->total_point - $task_point->task_point).'">';
						return $input;
					}),
					array( 'db' => 'id', 'dt' => 6, 'formatter' => function( $d, $row ) {
						//========================================	
						$employee_row = $this->DB->mysqlr_array("SELECT employee_id,basic_salary from employee where employee_id = '".$row[7]."'");
						$sallary_per_day = (float)$employee_row['basic_salary'];
						
						// add increament per day
						$check_increament = $this->DB->mysqlr_array("SELECT sum(amount) as total_inc from employee_increament_logs where employee_id = '" . $employee_row['employee_id'] . "' and aproval = '1' and start_date_modify <= '" . date('Ymd') . "'");
						if(!empty($check_increament['total_inc'])){
							$sallary_per_day = $sallary_per_day + $check_increament['total_inc'];
						}	
						
						// Remove decreament per day
						$check_decreament = $this->DB->mysqlr_array("SELECT sum(amount) as total_dec from employee_decreament_logs where employee_id = '" . $employee_row['employee_id'] . "' and aproval = '1' and start_date_modify <= '" . date('Ymd') . "'");
						if(!empty($check_decreament['total_dec'])){
							$sallary_per_day = $sallary_per_day - $check_decreament['total_dec'];
						}			
						//========================================

						$task_point = $this->db->query("SELECT task_point_table.*,task_list.title FROM task_point_table, task_list WHERE task_id='".$d."' AND task_point_table.task_id=task_list.id")->row();
						// this.value = !!this.value && Math.abs(this.value) >= 0 ? Math.abs(this.value) : null;
						$input  = '<input type="number" name="" id="assignee_point_'.$row[0].'" oninput=" bonus_calc(this,\''.$row[0].'\',\'head\')" value="'.$task_point->assignee_point.'">';
						$input .= '<span id="performance_bonus_head_'.$row[0].'" class="ml-1">'.(money_f(($sallary_per_day * $task_point->assignee_point) / 100)).'</span>';
						$input .= '<input type="hidden" id="sallary_per_day_head_'.$row[0].'" value="'.$sallary_per_day.'">';
						return $input;

					}),
					array( 'db' => 'assigned_by', 'dt' => 7, 'formatter' => function( $d, $row ) {
						$emp = $this->DB->mysqlr("SELECT full_name from employee WHERE employee_id='".$d."'");
						return !empty($emp->full_name)? $emp->full_name:'';
					}),
					array( 'db' => 'completed_at', 'dt' => 8, 'formatter' => function( $d, $row ) {
						return $d!='0000-00-00 00:00:00'?date('d M Y',strtotime($d)):'';
					}),				
					array( 'db' => 'id', 'dt' => 9, 'formatter' => function( $d, $row ) {
						$data ='';					
						if (isset($row[10]) && $row[10]==1 && $_SESSION['user_info']['department'] == '749568347163692080') {
							$data .= '<button class="btn btn-xs btn-info" id="point_button_'.$d.'" onclick="task_point_approval('.$d.')" >Approve</button>';
							$data .= '<button class="btn btn-xs btn-danger" id="reject_button_'.$d.'" onclick="task_point_reject('.$d.')" >Reject</button>';
						}
						return $data;
					}),
					array( 'db' => 'have_point', 'dt' => 10),
				);			
				echo json_encode( SSP::complex( $_POST, array( 'user' => db_info()['user'], 'pass' => db_info()['pass'], 'db'   => db_info()['db'], 'host' => db_info()['host'] ), $table, $primaryKey, $columns , $where , null) );
				exit();
			}

			
			$data['employee_info'] = $this->DB->mysqli("SELECT * FROM employee WHERE status=1");
			$data['department_info'] = $this->DB->mysqli("SELECT * FROM department WHERE status=1");
			$data['title_info'] = 'TODO List'; 
			$data['header'] = $this->load->view('include/header','',TRUE); 
			$data['nav'] = $this->load->view('include/nav','',TRUE); 
			$data['article'] = $this->load->view('template/tasks/task_point_approval',$data,TRUE); 
			$data['footer'] = $this->load->view('include/footer','',TRUE); 
			$this->load->view('dashboard',$data);
		}
	}
}
	<div class="content">
		<div class="container-flud">
			<div class="row">	
				<div class="col-sm-12 m-auto">
					<div class="card card-dark" style="white-space: normal;">
						<div class="card-header">
							<h3 class="card-title">Task Details</h3>
							
							<?php if (isset($task_priority)) { ?>
								<div class="float-right"><?=$task_priority?></div>
							<?php }elseif (isset($task_target)) { ?>
								<div class="float-right font-weight-bold"><?php echo !empty($onReview)? $onReview :'';?> Time Left: <?=$task_target?></div>
							<?php } ?>
						</div>
						<div class="card mb-3">
							<?php if($task_info->task_image): ?>
								<a href="<?= base_url()?>assets/uploads/task_list/<?=$task_info->task_image?>?view=true" target="_blank">
									<!-- <object data="<?= base_url()?>assets/uploads/task_list/<?=$task_info->task_image?>" class='card-img-top' style='max-height: 400px;'></object> -->
									<img src='<?= base_url()?>assets/uploads/task_list/<?=$task_info->task_image?>' class='card-img-top' style='max-height: 400px;' alt="Click to View">
								</a>
							<?php endif; ?>
							
							<div class="card-header text-muted">
								<small><?=!empty($task_info->emp_name_by) ? " Assigned by: $task_info->emp_name_by," : '' ?></small>
								<small><?=!empty($task_info->emp_name_to) ? " Assigned to: $task_info->emp_name_to," : '' ?></small>
								<small><?=!empty($task_info->emp_name_pro) ? " Processing By: $task_info->emp_name_pro," : '' ?></small>
								<small><?=!empty($task_info->emp_name_com) ? " Complete By: $task_info->emp_name_com," : '' ?></small>
								<?php
									if(!empty($task_info->accepted_at)){
										$phpdate = strtotime( $task_info->accepted_at );
										$mysqldate = date( 'd M Y', $phpdate );
									}
									
								?>
								<small><?=!empty($task_info->accepted_at) ? " Accepted at: $mysqldate," : '' ?></small>
								<?php
									if(!empty($task_info->deadline_at)){
										$phpdate = strtotime( $task_info->deadline_at );
										$mysqldate = date( 'd M Y', $phpdate );
									}
								?>
								<small><?=!empty($task_info->deadline_at) ? " Deadline at: $mysqldate," : '' ?></small>
								<?php
									if(!empty($task_info->completed_at)){
										$phpdate = strtotime( $task_info->completed_at );
										$mysqldate = date( 'd M Y', $phpdate );
									}
									
								?>
								<small><?=!empty($task_info->completed_at) ? " Completed at: $mysqldate," : '' ?></small>
								<small>Status: 
									<?php
									switch ($task_info->status) {
										case "1":
											echo 'Processing';
											break;
										case "2":
											echo 'Completed';
											break;
										default:
											echo 'Queue';
									}
									?>
								</small>
								<div>
									<?php 
									if (!empty($task_info->complain_id)) {
										$member_info = $this->db->query("SELECT * FROM member_directory WHERE id IN (SELECT member_directory_id FROM complain WHERE id='".$task_info->complain_id."')")->row();
									?>
										<fieldset class="border p-2">
											<legend class="w-auto m-0 text-primary" style="font-size:14px;">Member Info:</b></legend>
											<b>Name: </b><?php echo $member_info->full_name; ?>,
											<b>Phone: </b><?php echo $member_info->phone_number; ?>,
											<b>Branch: </b><?php echo $member_info->branch_name; ?>,
											<b>Floor: </b><?php echo $member_info->floor_name; ?>,
											<b>Room: </b><?php echo $member_info->room_name; ?>,
											<b>Bed: </b><?php echo $member_info->bed_name; ?>
										</fieldset>
									<?php } ?>
								</div>
							</div>
							<div class="card-body">
								<h3 class="my-3"><?=$task_info->title?></h3>
								
								<p class="card-text"><?php echo find_link($task_info->description); ?></p>
								<?php
									$task_point_t = $this->DB->mysqlr("SELECT `task_benefit` FROM `task_point_table` WHERE task_id='".$task_info->id."'");
									if (!empty($task_point_t->task_benefit)) {
										echo '<p class="card-text"><b>Task Benefit:</b> '.$task_point_t->task_benefit.'</p>';
									}
								?>
								<p class="card-text"><small class="text-muted font-weight-bolder"><?=$task_info->created_at?></small></p>
							</div>
						</div>
						<?php if (isset($task_point_data)) { 
							if ($task_point_data->task_type=='regular'){
								$max='max="100"';
								$min='min="5"';
								$placeholder = 'placeholder="Point 5% to 100%"';
							}else{
								$max='';
								$min='0';
								$placeholder='';
							}
						?>
						<!-- <form id="task_point_form" method="POST">
							<input type="hidden" name="approve_task_point">
							<input type="hidden" name="total_point" value="<?=$task_point_data->total_point - $task_point_data->task_point?>">
							<input type="hidden" name="task_id" value="<?=$task_point_data->task_id?>">
							<div class="form-group row mx-1">
								<label for="staticEmail" class="col-sm-3 col-form-label">Task Type</label>
								<div class="col-sm-9">
								<input type="text" readonly class="form-control-plaintext" id="staticEmail" value="<?=ucwords($task_point_data->task_type);?>">
								</div>
							</div>
							<div class="form-group row mx-1">
								<label for="task_point" class="col-sm-3 col-form-label">Task Point</label>
								<div class="col-sm-9">
								<input type="number" step="any" <?=$placeholder?> <?=$min?> <?=$max?> class="form-control d-inline-block" id="task_point" name="task_point" value="<?=ucwords($task_point_data->task_point);?>" style="max-width:250px;">
								<span> % performance bonus of 1 day's salary.</span>
								</div>
							</div>
							<div class="form-group row mx-1">
								<label for="task_point" class="col-sm-3 col-form-label">D-Head Point</label>
								<div class="col-sm-9">
									<input type="number" step="any" min="0" <?=$max?> class="form-control d-inline-block" id="task_point" name="assignee_point" value="0" style="max-width:250px;">
									<span> % performance bonus of 1 day's salary.</span>
								</div>
							</div>
							<button style="cursor: pointer; color: white;" type="submit" class="btn btn-success btn-block">
								<i class="fas fa-clipboard-check"></i> Approve
							</button>
						</form> -->
						<?php }else{ ?>		
						<div class="row">
							<h2 class="col-2 text-right">
								<i class="far fa-user-circle pt-4 text-info"></i>
							</h2>
							
							<form class="col-10" method="post">
								<label for="floatingTextarea">Comments</label>
								<input type="hidden" id="task_id" value="<?php echo $task_info->id; ?>">
								<div class="input-group col-8">
									<textarea class="form-control" id="comment_<?php echo $task_info->id; ?>" placeholder="Leave a comment here" aria-label="With textarea" rows="1"></textarea>
									<div class="input-group-prepend">
										<input type='button' value='Post' onclick='sendcomment(<?= $task_info->id ?>)' class='input-group-text'>
									</div>
								</div>
							</form>
						</div>
						<div id="view_<?php echo $task_info->id; ?>"> </div>
						<?php
							
							foreach($comment as $data) {
							$phpdate = strtotime( $data->created_at );
							$mysqldate = date( 'd M Y, h:i A', $phpdate )
						?>
						<div class="d-flex flex-row mt-3">
							<h2 class="col-2 text-right">
								<i class="far fa-user-circle pt-1 pr-2 text-info"></i>
							</h2>
							<div class="">
								<h5><?php echo $data->full_name ?> <small class="text-muted" style="font-size:11px"><?php echo $mysqldate ?></small></h5>
								<p><?php echo $data->comment ?></p>
							</div>
						</div>
						<?php } ?> 
						<div id="shows"> </div>
						<div class="btn-group btn-group-sm" role="group" aria-label="...">
							<button type="button" id="clicks" class="btn btn-secondary ms-4" value="<?php echo $task_info->id; ?>">Show More</button>
							<?php echo isset($editButton)? $editButton:''; ?>  
							<?php echo isset($pro_buttons)? $pro_buttons:''; ?>  
						</div>
						<?php if($task_info->status == '0' && ($_SESSION['super_admin']['employee_ids'] == $task_info->assigned_to || empty($task_info->assigned_to) || ($_SESSION['user_info']['d_head']=='1' && $_SESSION['user_info']['department']==$task_info->department_id) || !empty($task_info->complain_id))){ ?>
						<button style="cursor: pointer; color: white;" class="btn btn-success accept" data-task_accept="<?=$task_info->id; ?>" data-toggle="modal" data-target="#exampleModal2">
							<i class="fas fa-clipboard-check"></i> Accept the task!
						</button>
						<?php } ?>
						
						<?php if($task_info->status == '1' && (($task_info->assigned_by == $task_info->processing_by && $task_info->processing_by== $_SESSION['super_admin']['employee_ids']) || ($task_info->assigned_by== $_SESSION['super_admin']['employee_ids'] && !isset($task_complete_status)) || ($_SESSION['user_info']['d_head']=='1' && $_SESSION['user_info']['department']==$task_info->department_id))){ ?>
						<button style="cursor: pointer; color: white;" class="btn btn-danger complete" data-task_complete="<?=$task_info->id; ?>">
							<i class="fas fa-check-double"></i> Yes, Confirm Task is complete
						</button>
						<?php } 
						
						}?>
					</div>
				</div>				
			</div>
		</div>
	</div>
</div>

<script>
  /*---------------- make comment by ajax -------------*/
	function sendcomment(taskId){
		var task_id =taskId;
		var comment =$('#comment_'+taskId).val();
		if (comment.trim() != '') {
			$.ajax({
				// you can use both post and get method in this syntax
				method: "POST",
				url:"<?=base_url(); ?>/Task_list/comment", 
				data: {task_id: task_id, comment: comment}, 
				success: function(result){
					$('#comment').val('');
					var fresult=$("#view_"+taskId).html(); 
					result += fresult;
					$("#view_"+taskId).html(result);
				}
			});
		}
	
	};

 /*---------------- show more comment by ajax -------------*/
	$(document).ready(function () {
	var count = 0; 
		$("#clicks").click(function(){
		count+=3;
		var task_id =$(this).val();
		$.ajax({
			// you can use both post and get method in this syntax
			method: "POST",
			url:"<?=base_url(); ?>/Task_list/comment", 
			data: {count: count, task_id: task_id}, 
			success: function(result){
			$("#shows").html(result)
		}
		});
	});

	


	});

	/*---------------- show more comment by ajax -------------*/
	
	$(function () {
		$('[data-toggle="tooltip"]').tooltip();
	})
</script>
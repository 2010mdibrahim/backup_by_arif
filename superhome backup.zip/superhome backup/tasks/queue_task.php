
<thead>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Assigned By</th>
        <th>Assigned To</th>
        <th>Priority</th>
        <th>Deadline</th>
        <th>Action</th>
    </tr>
</thead>							
<?php
    if($_SESSION['user_info']['department'] == 749568347163692080){  //  $_SESSION['super_admin']['employee_ids'] == '72178'
?>
<tbody id='tdata'>
    <?php
        if(!empty($task_queue)){
        foreach($task_queue as $key=>$task): 
    ?>										
        <tr style="background: #5bff73; color: #2c00ff;" data-row="<?php echo $task->id; ?>" >
            <td><?php echo $task->id; ?></td>
            <td class="text-truncate" style="max-width: 150px;"><?php echo $task->title; ?></td>
            <td><?php echo $task->emp_name_by; ?></td>
            <td><b><?php echo $task->emp_name_to; ?></b></td>
            <td  style="font-size: 8px">
                <span class="fa fa-star <?=$task->priority_rate > 0 ? 'checked' : '' ?>"></span>
                <span class="fa fa-star <?=$task->priority_rate > 1 ? 'checked' : '' ?>"></span>
                <span class="fa fa-star <?=$task->priority_rate > 2 ? 'checked' : '' ?>"></span>
                <span class="fa fa-star <?=$task->priority_rate > 3 ? 'checked' : '' ?>"></span>
                <span class="fa fa-star <?=$task->priority_rate > 4 ? 'checked' : '' ?>"></span>
            </td>
            <td>
                    <?php
                    if ($task->deadline_at == "0000-00-00 00:00:00") {
                        echo '';
                    }else {
                    $phpdate = strtotime( $task->deadline_at );
                    $mysqldate = date( 'd M Y', $phpdate );
                    echo $mysqldate; 
                    }
                    ?>
            </td>
            <td class="d-flex">
                <!-- Button trigger modal for accept task -->
                <!-- <button style="cursor: pointer; color: white;" class="btn btn-xs btn-success accept" data-task_accept="<?php echo $task->id;?>" data-toggle="modal" data-target="#exampleModal2" <?php echo $task->assigned_to==$_SESSION['super_admin']['employee_ids'] || empty($task->assigned_to) ? '' : 'disabled'; ?> >
                    <i class="fas fa-clipboard-check"></i>
                </button> -->

                <!-- Button trigger modal for veiw -->
                <a href="#" data-task_info="<?php echo $task->id; ?>" class="btn btn-xs btn-warning task_veiw"><i class="fa fa-eye"></i></a>
                <!-- Button trigger modal for edit task -->
                <button href="#" data-task_edit="<?php echo $task->id; ?>" class="btn btn-xs btn-primary task_edit" data-toggle="modal" data-target="#exampleModal2" <?php echo $task->assigned_by==$_SESSION['super_admin']['employee_ids'] ? '' : 'disabled'; ?>><i class="fa fa-edit"></i></button>
            </td>
        </tr>
    <?php 
            endforeach; 
        }
    ?>
</tbody>
<?php
    }else{									
        if(!empty($_SESSION['super_admin']['employee_ids'])){
?>
<tbody id='tdata'>
    <?php
        if(!empty($task_queue_serial_1)){
        foreach($task_queue_serial_1 as $key=>$task): 
    ?>										
        <tr style="background: #5bff73; color: #2c00ff;" data-row="<?php echo $task->id; ?>">
            <td><?php echo $task->id; ?></td>
            <td class="text-truncate" style="max-width: 150px;"><?php echo $task->title; ?></td>
            <td><?php echo $task->emp_name_by; ?></td>
            <td><b><?php echo $task->emp_name_to; ?></b></td>
            <td  style="font-size: 8px">
                <span class="fa fa-star <?=$task->priority_rate > 0 ? 'checked' : '' ?>"></span>
                <span class="fa fa-star <?=$task->priority_rate > 1 ? 'checked' : '' ?>"></span>
                <span class="fa fa-star <?=$task->priority_rate > 2 ? 'checked' : '' ?>"></span>
                <span class="fa fa-star <?=$task->priority_rate > 3 ? 'checked' : '' ?>"></span>
                <span class="fa fa-star <?=$task->priority_rate > 4 ? 'checked' : '' ?>"></span>
            </td>
            <td>
                    <?php
                    if ($task->deadline_at == "0000-00-00 00:00:00") {
                        echo '';
                    }else {
                    $phpdate = strtotime( $task->deadline_at );
                    $mysqldate = date( 'd M Y', $phpdate );
                    echo $mysqldate; 
                    }
                    ?>
            </td>
            <td class="d-flex">
                

                <!-- Button trigger modal for veiw -->
                <a href="#" data-task_info="<?php echo $task->id; ?>" class="btn btn-xs btn-warning task_veiw"><i class="fa fa-eye"></i></a>
                <!-- Button trigger modal for edit task -->
                <button href="#" data-task_edit="<?php echo $task->id; ?>" class="btn btn-xs btn-primary task_edit" data-toggle="modal" data-target="#exampleModal2" <?php echo $task->assigned_by==$_SESSION['super_admin']['employee_ids'] ? '' : 'disabled'; ?>><i class="fa fa-edit"></i></button>
            </td>
        </tr>
    <?php 
            endforeach; 
        }
    ?>
    
    <?php 
        if(!empty($task_queue_serial_2)){
            foreach($task_queue_serial_2 as $key=>$task): ?>										
        <tr data-row="<?php echo $task->id; ?>">
                <td><?php echo $task->id; ?></td>
                <td class="text-truncate" style="max-width: 150px;"><?php echo $task->title; ?></td>
                <td><?php echo $task->emp_name_by; ?></td>
                <td><?php echo $task->emp_name_to; ?></td>
                <td  style="font-size: 8px">
                    <span class="fa fa-star <?=$task->priority_rate>0 ? 'checked' : '' ?>"></span>
                    <span class="fa fa-star <?=$task->priority_rate>1 ? 'checked' : '' ?>"></span>
                    <span class="fa fa-star <?=$task->priority_rate>2 ? 'checked' : '' ?>"></span>
                    <span class="fa fa-star <?=$task->priority_rate>3 ? 'checked' : '' ?>"></span>
                    <span class="fa fa-star <?=$task->priority_rate>4 ? 'checked' : '' ?>"></span>
                </td>
                <td>
                    <?php
                    if ($task->deadline_at == "0000-00-00 00:00:00") {
                        echo '';
                    }else {
                    $phpdate = strtotime( $task->deadline_at );
                    $mysqldate = date( 'd M Y', $phpdate );
                    echo $mysqldate; 
                    }
                    ?>
                </td>
            <td class="d-flex">
                <!-- Button trigger modal for accept task -->
                <button style="cursor: pointer; color: white;" class="btn btn-xs btn-success accept"
                    data-task_accept="<?php echo $task->id;?>"
                    data-toggle="modal" data-target="#exampleModal2"
                    <?php echo $task->assigned_to==$_SESSION['super_admin']['employee_ids'] || empty($task->assigned_to) ? '' : 'disabled'; ?>
                    >
                    <i class="fas fa-clipboard-check"></i>
                </button>

                <!-- Button trigger modal for veiw -->
                <a href="#" data-task_info="<?php echo $task->id; ?>" class="btn btn-xs btn-warning task_veiw"><i class="fa fa-eye"></i></a>
                <!-- Button trigger modal for edit task -->
                <button href="#" data-task_edit="<?php echo $task->id; ?>" class="btn btn-xs btn-primary task_edit" data-toggle="modal" data-target="#exampleModal2" <?php echo $task->assigned_by==$_SESSION['super_admin']['employee_ids'] ? '' : 'disabled'; ?>><i class="fa fa-edit"></i></button>
            </td>
        </tr>
    <?php 
            endforeach; 
        }
    ?>
</tbody>							
<?php 
}
}
?>
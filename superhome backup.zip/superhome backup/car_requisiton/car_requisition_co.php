<?php
 function car_requisitons() {
    if (!isset($_SESSION['super_admin']['email'])) 
    { 
        redirect(base_url('admin/login')); 
    }else {
        if (!empty($this->input->post('available_car_list'))) {
            $car_registration_info = $this->DB->mysqli("SELECT * FROM `car_registration_info` WHERE `status`=1 AND `booked_status`=0");
            $options = '';
            foreach ($car_registration_info as $key => $car_registration) {
                $options .= '<option value="'.$car_registration->id.'">'.$car_registration->car_model.'</option>';
            }
            echo $options;
            exit;
        }
        
        if (!empty($this->input->post('car_requisition_acknowledge'))) {
            // notification
            $url = 'http://erp.superhostelbd.com/neways_employee_mobile_application/v1/api/push-notification';
            $method = 'POST';
            $head=['Content-Type: application/json'];
            // notification end;

            $car_requisitions = $this->DB->mysqlr("SELECT * FROM car_requisitions WHERE id='".$this->input->post('id')."'");

            
            $data = array(
                'car_id' => !empty($this->input->post('car_id')) ? $this->input->post('car_id') : '',
                'status' =>$this->input->post('status'),
                'approver_note' => !empty($this->input->post('note')) ? $this->input->post('note') : '',
                'approve_by' => $_SESSION['super_admin']['employee_ids']
            );

            $datum = array(
                'booked_status' => 1
            );

            if ($this->input->post('status') == 3 && !empty($this->input->post('car_id')) && 
                $this->DB->update('car_requisitions',$data,$this->input->post('id'))) 
            {
                $this->DB->update('car_registration_info',$datum,$this->input->post('car_id'));
                $body = [
                    'employee_id' => $car_requisitions->employee_id,
                    'title' => 'Car Requisition Approve.',
                    'message' => 'Car Requisition Approve By HR.',
                ];
                myCurl_request($url,$method,json_encode($body),$head);
                $response= array(
                    'status'=>1,
                    'message'=>'Successfully Accepted!',
                );
            }elseif ($this->input->post('status') == 6 && $this->DB->update('car_requisitions',$data,$this->input->post('id'))) 
            {
                $notify_employee = ['00002', $car_requisitions->employee_id];
                foreach ($notify_employee as $key => $emp) {
                    $body = [
                        'employee_id' => $emp,
                        'title' => 'Car Requisition Reject.',
                        'message' => $this->input->post('note'),
                    ];
                    myCurl_request($url,$method,json_encode($body),$head);
                }
                $response= array(
                    'status'=>1,
                    'message'=>'Successfully Rejected!',
                );
            }else 
            {
                $response= array(
                    'status'=>0,
                    'message'=>'Something Wrong! Try later.',
                );
            }
            
            echo json_encode($response);
            exit;
        }

        if(!empty($this->input->post('car_requisition_approval'))) {
            if ($this->input->post('type') == 'approve') {
                $data = array(
                    'status' =>1,
                    'approve_by' => $_SESSION['super_admin']['employee_ids']
                );
                $message =  'Approved Successfully!';
            }elseif ($this->input->post('type') == 'reject'){
                $data = array(
                    'status' =>2,
                    'approve_by' => $_SESSION['super_admin']['employee_ids']
                );
                $message =  'Rejected Successfully!';
            }
            
            if ($this->DB->update('car_requisitions',$data,$this->input->post('id'))) {
                $response= array(
                    'status'=>1,
                    'message'=>$message,
                );
            }else{
                $response= array(
                    'status'=>0,
                    'message'=>'Something Wrong! Try later.',
                );
            }
            echo json_encode($response);
            exit;
        }

        if (isset($_GET['get-data-table'])) {
            
            $table = "car_requisitions";
            $primaryKey = 'id';
            if ($_SESSION['user_info']['department']=='749568347163692080') {
                $where = 'status=0';
            }else {
                $where = 'status=1';
            }
            $columns = array(
                array( 'db' => 'id', 'dt' => 0 ),
                array( 'db' => 'employee_id','dt' => 1,
                'formatter' => function( $d, $row ) {
                    $emp = $this->DB->mysqlr("SELECT full_name,photo FROM employee WHERE employee_id='".$d."'");
                    return  '<img src="'.base_url($emp->photo).'" style="width: 50px;" class="mr-2">'.$emp->full_name;
                }),
                array( 'db' => 'car_id','dt' => 2,
                'formatter' => function( $d, $row ) {
                    $car = $this->DB->mysqlr("SELECT car_model,car_image FROM car_registration_info WHERE id='".$d."'");
                    if (!empty($car->car_model)) {
                        return  '<img src="'.base_url($car->car_image).'" style="width: 50px;" class="mr-2">'.$car->car_model;
                    }else {
                        return 'Not assigned Yet.';
                    }
                }),
                array( 'db' => 'destination_form', 'dt' => 3 ),
                array( 'db' => 'destination_to','dt' => 4 ),
                array( 'db' => 'travel_type', 'dt' => 5 ),
                array( 'db' => 'note',  'dt' => 6),
                array( 'db' => 'departure_timestamp', 'dt' => 7,
                'formatter' => function( $d, $row ) {
                        return date("Y-m-d h:i:s a", $d);
                }),
                array( 'db' => 'status','dt'  => 8,
                    'formatter' => function( $d, $row ) {
                        if($d==0){
                            return '<span class="badge badge-warning">Boss Pending</span>';
                        }elseif ($d==1) {
                            return '<span class="badge badge-success">Boss Approve AND HR Pending</span>';
                        }elseif($d==2){
                            return '<span class="badge badge-danger">Boss Rejected</span>';
                        }
                    }
                ),
                array(
                    'db'        => 'created_at',
                    'dt'        => 9,
                    'formatter' => function( $d, $row ) {
                        list($date, $time) = explode(' ',$d);
                        return $date;
                    }
                ),
                array(
                    'db'        => 'id',
                    'dt'        => 10,
                    'formatter' => function( $d, $row ) {
                        $emp = $this->DB->mysqlr("SELECT full_name,photo FROM employee WHERE employee_id='".$row['employee_id']."'");
                        $data= '';
                        if ($_SESSION['user_info']['department']=='749568347163692080') {
                            $data .= '<button class="btn btn-success btn-xs" onclick="carReqAprroval('.$d.',\'approve\',\'boss\')">Approve</button>';
                            $data .= '<button class="btn btn-danger btn-xs" onclick="carReqAprroval('.$d.',\'reject\',\'boss\')">Reject</button>';
                        }else{
                            $html = '<img src="'.base_url($emp->photo).'" style="width: 80px;" class="mr-2">
                                        <div><b>Name:</b> '.$emp->full_name.'</div>
                                        <div><b>Destination Form:</b> '.$row['destination_form'].'</div>
                                        <div><b>Destination To:</b> '.$row['destination_to'].'</div>
                                        <div><b>Departure Time:</b> '.date("Y-m-d h:i:s a",$row['departure_timestamp']).'</div>';
                             
                            $data .= '<button class="btn btn-primary btn-xs" onclick="acknowledgeFun('.$d.',\''.base64_encode($html).'\')">Approve</button>';
                        }
                        return $data;
                    }
                )
                
            );
            echo json_encode( SSP::complex( $_GET, array( 'user' => db_info()['user'], 'pass' => db_info()['pass'], 'db'   => db_info()['db'], 'host' => db_info()['host'] ), $table, $primaryKey, $columns , $where , null) );
            exit;
        }
        
        $data['title_info'] = 'HR | Car Requisiton Request';
        $data['header'] = $this->load->view('include/header', '', TRUE);
        $data['nav'] = $this->load->view('include/nav', '', TRUE);
        $data['article'] = $this->load->view('template/hrm/car_requisitons', $data, TRUE);
        $data['footer'] = $this->load->view('include/footer', '', TRUE);
        $this->load->view('dashboard', $data);
    }
}

<link rel="stylesheet" type="text/css" href="<?=base_url('assets/plugins/toastr/toastr.min.css');?>">
<div class="content-wrapper">
	    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Car Requisition</h1>
          </div> 
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?=base_url();?>">Home</a></li>
              <li class="breadcrumb-item active">Car Requisition</li>
            </ol>
          </div> 
        </div> 
      </div> 
    </div>
	

	<div class="content">
		<div class="container-flud">
			<div class="row">		
				<div class="col-sm-10 m-auto">
					<div class="card card-info">
						<div class="card-header">
							<h3 class="card-title">Car Requisition Requests</h3>
						</div>
						<div class="card-body">
							<div class="card card-primary card-outline card-outline-tabs">
								<!-- <div class="card-header p-0 border-bottom-0">
									<ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
										<li class="nav-item">
											<a class="nav-link active" id="custom-tabs-four-home-tab" data-toggle="pill" href="#custom-tabs-four-home" role="tab" aria-controls="custom-tabs-four-home" aria-selected="true">Active</a>
										</li>										
									</ul>
								</div> -->
								<div class="card-body">
									<div class="tab-content" id="custom-tabs-four-tabContent">
										<div class="tab-pane fade active show" id="custom-tabs-four-home" role="tabpanel" aria-labelledby="custom-tabs-four-home-tab">
											<div class="export_buttons"></div>
											<table class="table table-striped table-bordered table-sm small" id="activeTable" style="width:100%">
												<thead>
													<tr>
														<th>SL</th>
														<th>Employee</th>
														<th>Car Model</th>
														<th>Destination Form</th>
														<th>Destination To</th>
														<th>Travel Type</th>
														<th>Note</th>
														<th>Departure Time</th>
														<th>Status</th>
														<th>Created</th>
														<th>Options</th>
													</tr>
												</thead>
												<tbody>									
												</tbody>
											</table>
										</div>								
									</div>
								</div>
							</div>
						</div>					
					</div>
				</div>
	

			</div>
		</div>
	</div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalContent">
      </div>      
	  <div class="modal-footer">
        <button type="button" onclick="finalSubmit(this);" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>

<script>
$('document').ready(function(){
    // var status_filter = '<label style="margin-left: 10px;"> Status: ';
    // status_filter += '<select class="status_filter custom-select-sm form-control form-control-sm select2">';
    // status_filter += '<option value="">--select--</option>';
    // status_filter += '<option value="0">Pending</option>';
    // status_filter += '<option value="1">Approved</option>';
    // status_filter += '<option value="2">Reject</option>';
    // status_filter += '</select></label>';
	
    // setTimeout(() => {
    //   $('.dataTables_length').append(status_filter);
    //   $('.select2').select2();
    // }, 500);

	var active_table = $('#activeTable').DataTable({
		"paging": true,
		"lengthChange": true,
		"lengthMenu": [
			[10, 25, 50, 100, 500],
			[10, 25, 50, 100, 500]
		],
		"searching": true,
		"ordering": true,
		"order": [[ 0, "desc" ]],
        "zeroRecords":    "No matching records found",
        "search":         "Search:",
		//"info": true,
		//"autoWidth": true,
		//"responsive": true,
		"ScrollX": true,
		"processing": true,
        "serverSide": true,
		"ajax": "<?=current_url(); ?>?get-data-table=active",  
		"initComplete": function () {
			// $('.dataTables_length').append(status_filter);
			// $('.select2').select2();
		} ,     
		dom: 'lBfrtip',
        buttons: [			
            {
                extend: 'copy',
                text: '<i class="fas fa-copy"></i> Copy',
                titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'excel',
                text: '<i class="fas fa-file-excel"></i> Excel',
                titleAttr: 'Excel',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'csv',
                text: '<i class="fas fa-file-csv"></i> CSV',
                titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
                text: '<i class="fas fa-file-pdf"></i> PDF',
                titleAttr: 'PDF'
            }, {
                extend: 'print',
                footer: true,
                text: '<i class="fas fa-print"></i> Print',
                titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'colvis',
                text: '<i class="fas fa-list"></i> Column Visibility',
                titleAttr: 'Column Visibility'
            }
		]

    });
	active_table.buttons().container().appendTo($('.export_buttons'));
})


function acknowledgeFun(id,htmls) {
	Swal.fire({
		title: "Did you find out?",
		html: atob(htmls),
		showDenyButton: true,
		showCancelButton: true,
		confirmButtonText: "Accept",
		denyButtonText: `Reject`
		})
		.then((result) => {
			/* Read more about isConfirmed, isDenied below */
			if (result.isConfirmed) {
				$.ajax({
					url: "<?php echo current_url() ?>",
					type: "POST",
					async: true,
					data: { available_car_list:1},
					success: function (res) {
						if (res != '') {
							var html = `<select id="car_id" class="form-control">${res}</select>
										<input type="hidden" id="status" value="3">
										<input type="hidden" id="requisiton_id" value="${id}">`;

							$('.modalContent').html(html);
							$("#myModal").modal('show');
							option = res;
						}else{
							toastr.error('No car available!');
						}
					},
					error: function (xhr, exception) {
						toastr.error('Something Wrong!');
					}
				}); 
			}else if (result.isDenied) {
				var html = `<input type="text" class="form-control" id="aprover_note" placeholder="Reject Note" autofocus required>
							<input type="hidden" id="status" value="6">
							<input type="hidden" id="requisiton_id" value="${id}">`;
				$('.modalContent').html(html);
				$("#myModal").modal('show');
			}
		});
}

function finalSubmit(these){
	var id= $("#requisiton_id").val();
	var note= $("#aprover_note").val();
	var car_id= $("#car_id").val();
	var status= $("#status").val();
	$.ajax({
		url: "<?php echo current_url() ?>",
		type: "POST",
		async: true,
		data: { car_requisition_acknowledge:1, id, note, car_id, status},
		success: function (res) {	
			var data = JSON.parse(res);
			if (data.status == 1) {
				toastr.success(data.message);
				$('#activeTable').DataTable().ajax.reload( null , false);
			}else{
				toastr.error('Something Wrong!');
			}
			$("#myModal").modal('hide');
		},
		error: function (xhr, exception) {
			toastr.error('Something Wrong!');
		}
	}); 
}

function carReqAprroval(id,type,person) {
	if (confirm("Are you sure about "+type)) {
		$.ajax({
			url: "<?php echo current_url() ?>",
			type: "POST",
			async: true,
			data: { car_requisition_approval:1, id, type, person},
			success: function (res) {	
				var data = JSON.parse(res);
				if (data.status == 1) {
					toastr.success(data.message);
					$('#activeTable').DataTable().ajax.reload( null , false);
				}else{
					toastr.error('Something Wrong!');
				}
			},
			error: function (xhr, exception) {
				toastr.error('Something Wrong!');
			}
		});
	} 
}
</script>
<script src="<?=base_url('assets/plugins/toastr/toastr.min.js');?>"> </script>
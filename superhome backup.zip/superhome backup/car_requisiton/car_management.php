
<link rel="stylesheet" type="text/css" href="<?=base_url('assets/plugins/toastr/toastr.min.css');?>">
<div class="content-wrapper">
	    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Car Management</h1>
          </div> 
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?=base_url();?>">Home</a></li>
              <li class="breadcrumb-item active">Car Management</li>
            </ol>
          </div> 
        </div> 
      </div> 
    </div>
	

	<div class="content">
		<div class="container-flud">
			<div class="row">
				<div class="col-sm-4">
					<div class="card card-primary">
						<div class="card-header">
							<h3 class="card-title">Add New Car Info</h3>
						</div>
						<form role="form" action="<?=current_url(); ?>" id="car_registration_form" method="post" enctype="multipart/form-data">
							<input type="hidden" id="submit_car_registration" name="save_car_registration" value="save"/>
							<input type="hidden" name="update_id" value="">
							<div class="card-body">
								<div class="form-group">
									<label>Car Model</label>
									<input type="text" name="car_model" class="form-control" placeholder="Car Model" id="car_model" required/>
								</div>
								<div class="form-group">
									<label>Car Plate Number</label>
									<input type="text" name="car_plate_number" class="form-control" placeholder="Car Plate Number" required>
								</div>
								<div class="form-group">
									<label>Car Color</label>
									<input type="text" name="car_color" class="form-control" placeholder="Car Color Name" required>
								</div>
								<div class="form-group">
									<label for="registration_date">Car Buy/Rent Date</label>
									<div class="input-group">
										<input type="date" name="registration_date" id="registration_date" class="form-control" required>
									</div>
								</div>
								<div class="form-group">
									<label for="vehicle_type">Vehicle Type</label>
									<div class="input-group">
										<select name="vehicle_type" id="vehicle_type" class="form-control" required>
											<option value="">--select--</option>
											<option value="car">Car</option>
											<option value="bike">Bike</option>
										</select>
									</div>
								</div>
								<div class="form-group driver-container" style="display:none;">
									<label for="driver">Driver</label>
									<div class="input-group">
										<select name="employee_id" id="driver" class="form-control">
											<option value="">--select--</option>
											<?php 
												foreach ($drivers as $key => $driver) {
													echo '<option value="'.$driver->employee_id.'">'.$driver->full_name.'</option>';
												}
											?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="valuation_type">Car Valuation Type</label>
									<div class="input-group">
										<select name="valuation_type" id="valuation_type" class="form-control" required>
											<option value="">--select--</option>
											<option value="buy">Buy</option>
											<option value="rent">Rent</option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="price">Car Buy/Monthly Rent Price</label>
									<div class="input-group">
										<input type="number" step="any" min="0" name="price" id="price" class="form-control" required>
									</div>
								</div>
								<div class="form-group">
									<label>Car mileage</label>
									<input type="number" min="0" name="car_mileage" class="form-control" placeholder="Car Mileage in Kilometer" required>
								</div>
								<div class="form-group">
									<label>Number of Seat</label>
									<input type="number" min="0" name="number_of_seat" class="form-control" placeholder="Car Seat Number" required>
								</div>
								<div class="form-group">
									<label>Car Image</label>
									<input type="file" name="car_image" class="form-control">
								</div>
								<div class="form-group form-check">
									<input type="checkbox" class="form-check-input" name="status" id="status" value="1" checked>
									<label class="form-check-label" for="status">Active</label>
								</div>
							</div>
							<div class="card-footer">
								<button type="submit" id="submit_button" name="save" class="btn btn-primary">Save</button>
							</div>
						</form>
					</div>
				</div>				
				
				<div class="col-sm-8">
					<div class="card card-info">
						<div class="card-header">
							<h3 class="card-title">Registered Car List</h3>
						</div>
						<div class="card-body">
							<div class="card card-primary card-outline card-outline-tabs">
								<div class="card-header p-0 border-bottom-0">
									<ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
										<li class="nav-item">
											<a class="nav-link active" id="custom-tabs-four-home-tab" data-toggle="pill" href="#custom-tabs-four-home" role="tab" aria-controls="custom-tabs-four-home" aria-selected="true">Active</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" id="custom-tabs-four-profile-tab" data-toggle="pill" href="#custom-tabs-four-profile" role="tab" aria-controls="custom-tabs-four-profile" aria-selected="false">In-active</a>
										</li>										
									</ul>
								</div>
								<div class="card-body">
									<div class="tab-content" id="custom-tabs-four-tabContent">
										<div class="tab-pane fade active show" id="custom-tabs-four-home" role="tabpanel" aria-labelledby="custom-tabs-four-home-tab">
											<div class="export_buttons"></div>
											<table class="table table-striped table-bordered table-sm small" id="activeTable" style="width:100%">
												<thead>
													<tr>
														<th>SL</th>
														<th>Car Model</th>
														<th>Plate No.</th>
														<th>Color</th>
														<th>Registration</th>
														<th>Purchase Type</th>
														<th>Rent/Buy Price</th>
														<th>Car Mileage</th>
														<th>Car Image</th>
														<th>Status</th>
														<th>Uploader</th>
														<th>Options</th>
													</tr>
												</thead>
												<tbody>									
												</tbody>
											</table>
										</div>
										<div class="tab-pane fade" id="custom-tabs-four-profile" role="tabpanel" aria-labelledby="custom-tabs-four-profile-tab">
											<div class="export_buttons_1"></div>
											<table class="table table-striped table-bordered table-sm small" id="inactiveTable" style="width:100%">
												<thead>
													<tr>
														<th>SL</th>
														<th>Car Model</th>
														<th>Plate No.</th>
														<th>Color</th>
														<th>Registration</th>
														<th>Purchase Type</th>
														<th>Rent/Buy Price</th>
														<th>Car Mileage</th>
														<th>Status</th>
														<th>Uploader</th>
													</tr>
												</thead>
												<tbody>									
												</tbody>
											</table>
										</div>									
									</div>
								</div>
							</div>
						</div>					
					</div>
				</div>
	

			</div>
		</div>
	</div>
</div>
<!-- Modal -->
<div class="modal fade" id="passModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<input type="hidden" id="pass_id">
        <input type="password" class="form-control" id="checkPass" placeholder="Give your login password, minimum length 4" autofocus>
      </div>
    </div>
  </div>
</div>

<script>
$('document').ready(function(){
	var active_table = $('#activeTable').DataTable({
		"paging": true,
		"lengthChange": true,
		"lengthMenu": [
			[10, 25, 50, 100, 500],
			[10, 25, 50, 100, 500]
		],
		"searching": true,
		"ordering": true,
		"order": [[ 0, "desc" ]],
        "zeroRecords":    "No matching records found",
        "search":         "Search:",
		//"info": true,
		//"autoWidth": true,
		//"responsive": true,
		"ScrollX": true,
		"processing": true,
        "serverSide": true,
		"ajax": "<?=current_url(); ?>?get-data-table=active",        
		dom: 'lBfrtip',
        buttons: [			
            {
                extend: 'copy',
                text: '<i class="fas fa-copy"></i> Copy',
                titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'excel',
                text: '<i class="fas fa-file-excel"></i> Excel',
                titleAttr: 'Excel',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'csv',
                text: '<i class="fas fa-file-csv"></i> CSV',
                titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
                text: '<i class="fas fa-file-pdf"></i> PDF',
                titleAttr: 'PDF'
            }, {
                extend: 'print',
                footer: true,
                text: '<i class="fas fa-print"></i> Print',
                titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'colvis',
                text: '<i class="fas fa-list"></i> Column Visibility',
                titleAttr: 'Column Visibility'
            }
		]

    });
	active_table.buttons().container().appendTo($('.export_buttons'));


	var inactive_table = $('#inactiveTable').DataTable({
		"paging": true,
		"lengthChange": true,
		"lengthMenu": [
			[10, 25, 50, 100, 500],
			[10, 25, 50, 100, 500]
		],
		"searching": true,
		"ordering": true,
		"order": [[ 0, "desc" ]],
        "zeroRecords":    "No matching records found",
        "search":         "Search:",
		//"info": true,
		//"autoWidth": true,
		//"responsive": true,
		"ScrollX": true,
		"processing": true,
        "serverSide": true,
		"ajax": "<?=current_url(); ?>?get-data-table=inactive",        
		dom: 'lBfrtip',
        buttons: [			
            {
                extend: 'copy',
                text: '<i class="fas fa-copy"></i> Copy',
                titleAttr: 'Copy',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'excel',
                text: '<i class="fas fa-file-excel"></i> Excel',
                titleAttr: 'Excel',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'csv',
                text: '<i class="fas fa-file-csv"></i> CSV',
                titleAttr: 'CSV',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'pdf',
				exportOptions: { columns: ':visible' },
				orientation: 'landscape',
				pageSize: "LEGAL",
                text: '<i class="fas fa-file-pdf"></i> PDF',
                titleAttr: 'PDF'
            }, {
                extend: 'print',
                footer: true,
                text: '<i class="fas fa-print"></i> Print',
                titleAttr: 'Print',
				exportOptions: { columns: ':visible' }
            }, {
                extend: 'colvis',
                text: '<i class="fas fa-list"></i> Column Visibility',
                titleAttr: 'Column Visibility'
            }
		]

    });
	inactive_table.buttons().container().appendTo($('.export_buttons_1'));
})

$("#car_registration_form").on('submit', (function(e) {
    e.preventDefault();
    $.ajax({
      url: $(this).attr('action'),
      type: "POST",
      data: new FormData(this),
      contentType: false,
      cache: false,
      processData: false,
		beforeSend:function(){					
			$('#data-loading').html(data_loading);					 
		},
      success: function(res) {
		$('#data-loading').html('');		
		if (res=="success") {
			toastr.success('Successfully Save!');
			$('#submit_button').text('Save');
			$('input[name="update_id"]').val('');
		}else if (res=="exist") {
			toastr.warning('Car plate number already exist!');
		}else {
			toastr.error('Something Wrong! Try again');
		}
		$('#activeTable').DataTable().ajax.reload( null , false);
        $("#car_registration_form").trigger("reset"); // to reset form input fields
      },
      error: function(e) {
			toastr.error('Something Wrong!');
      }
    });
  }));


function editFunction(id) {
	$.ajax({
		url: "<?php echo current_url() ?>",
		type: "POST",
		async: true,
		data: { edit_car_registration:1, id:id},
		success: function (res) {	
			var data = JSON.parse(res);
			if (data.status == 1) {
				var car = data.data;
				$('input[name="car_model"]').val(car.car_model);
				$('input[name="car_plate_number"]').val(car.car_plate_number);
				$('input[name="car_color"]').val(car.car_color);
				$('input[name="registration_date"]').val(car.registration_date);
				$('select[name="vehicle_type"]').val(car.vehicle_type).trigger("change");
				$('select[name="employee_id"]').val(car.employee_id);
				$('select[name="valuation_type"]').val(car.valuation_type);
				$('input[name="price"]').val(car.price);
				$('input[name="car_mileage"]').val(car.car_mileage);
				$('input[name="update_id"]').val(car.id);
				$('#submit_button').text('Update');
			}else if(data.status == 0){
				toastr.error(data.message);
			}else{
				toastr.error('Something Wrong!');
			}
		},
		error: function (xhr, exception) {
			toastr.error('Something Wrong!');
		}
	}); 
}

$("#vehicle_type").change(function(){
	if ($(this).val()=='car') {
		$('.driver-container').show();
		$('.driver-container').find('select').prop('required',true);
	}else{
		$('.driver-container').hide();
		$('.driver-container').find('select').prop('required',false);
	}
})
</script>
<script src="<?=base_url('assets/plugins/toastr/toastr.min.js');?>"> </script>
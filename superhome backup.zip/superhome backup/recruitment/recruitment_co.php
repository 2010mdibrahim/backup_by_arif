<?php
//---------Start today_candidate_attendance-------------
	function today_candidate_attendance()
	{
		$data = array();
		if (!isset($_SESSION['super_admin']['email'])) {
			redirect(base_url('admin/login'));
		} else {
			$data['title_info'] = 'Today Candidate Attendance';
			$data['header'] = $this->load->view('include/header', '', TRUE);
			$data['nav'] = $this->load->view('include/nav', '', TRUE);
			$data['article'] = $this->load->view('template/hrm/recruitment/today_candidate_attendance', $data, TRUE);
			$data['footer'] = $this->load->view('include/footer', '', TRUE);
			$this->load->view('dashboard', $data);
		}
	}
	//end exit today_candidate_attendance


	//---------Start candidate_shortlist-------------
	function candidate_shortlist()
	{
		$data = array();
		if (!isset($_SESSION['super_admin']['email'])) {
			redirect(base_url('admin/login'));
		} else {
			$data['title_info'] = 'Candidate Shortlist';
			$data['header'] = $this->load->view('include/header', '', TRUE);
			$data['nav'] = $this->load->view('include/nav', '', TRUE);
			$data['article'] = $this->load->view('template/hrm/recruitment/candidate_shortlist', $data, TRUE);
			$data['footer'] = $this->load->view('include/footer', '', TRUE);
			$this->load->view('dashboard', $data);
		}
	}
	//end exit candidate_shortlist
    
	//---------Start recruitment_approved_logs-------------HR
	function recruitment_approved_logs() { $data = array(); if (!isset($_SESSION['super_admin']['email'])) { redirect(base_url('admin/login')); } else {
		if(!empty($this->input->get('data-table')) AND $this->input->get('data-table') == 'active'){
			$table 			= 'employee_recruitment_request';
			$primaryKey 	= 'id';
			$where 			= "";				
			$columns 		= array(
				array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $d; }),
			);	
			echo json_encode( SSP::complex( $_POST, array( 'user' => db_info()['user'], 'pass' => db_info()['pass'], 'db'   => db_info()['db'], 'host' => db_info()['host'] ), $table, $primaryKey, $columns , $where , null) );
			exit();
		}	
			

		$data['table'] = $this->Dashboard_model->mysqlii("select * from employee_recruitment_request where boss_aproval = '1' order by id desc limit 200");
		$data['designation'] = $this->Dashboard_model->mysqlii("select * from designation");
		$data['title_info'] = 'Payroll - Employee Recruitment Request';
		$data['header'] = $this->load->view('include/header', '', TRUE);
		$data['nav'] = $this->load->view('include/nav', '', TRUE);
		$data['article'] = $this->load->view('template/hrm/payroll/employee_recruitment_approval', $data, TRUE);
		$data['footer'] = $this->load->view('include/footer', '', TRUE);
		$this->load->view('dashboard', $data);
	}}
	//---------end exit recruitment_approved_logs----------
<?php
     function car_list() {
        try {
            $car_registration_info = DB::table('car_registration_info')->select('*')->where('status','=','1')->where('booked_status','=','0')->get()->toArray();
            return response()->json(['status' => 1, 'message' => 'Car list.', 'data'=>$car_registration_info]);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }

     function car_requisition(Request $request) {
        try {
            // Validate the request data
            $validator = Validator::make($request->all(), [
                'destination_form' => 'required',
                'destination_to' => 'required',
                'travel_type' => 'required',
                'note' => 'required',
                'departure_date' => 'required'
            ]);

            if ($validator->fails()) {
                // Return validation errors in JSON format
                return response()->json(['status' => 0, 'message' => $validator->errors()], 422);
            }

            $user = $this->guard()->user();	
            $data= array(
                'employee_id' => $user->employee_id,
                'destination_form' => $request->destination_form,
                'destination_to' => $request->destination_to,
                'travel_type' => $request->travel_type,
                'note' => $request->note,
                'departure_timestamp' => strtotime("$request->departure_date $request->departure_time"),
                'departure_date' => $request->departure_date,
                'status' => 1, // added by ibrahim khalil (27-10-2024)
                'approver_note' => 'Auto Approved', // added by ibrahim khalil (27-10-2024)
                'approve_by' => '00002', // added by ibrahim khalil (27-10-2024)
            );

            $hr_employee = DB::table('employee')->select('employee_id')->where('status','=','1')->where('department','=','1383007286312996344')->where(function ($query) {
                $query->where('grade_name', '=', 'M-3')
                    ->orWhere('grade_name', '=', 'E-3');
            })->get();

            foreach ($hr_employee as $key => $emp) {
                FirebaseMessage::send($emp->employee_id,'Car Requisition Request.', $request->note);
            }

            DB::table('car_requisitions')->insert($data);
            return response()->json(['status' => 1, 'message' => 'Succesfully send request!']);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => 'Fail to send request! Try later.', 'data' => $e->getMessage()]);
        }
    }

     function car_requisition_list() {
        try {
            $car_requisitions_today = DB::table('car_requisitions')
                                        ->leftJoin('employee', 'employee.employee_id', '=', 'car_requisitions.employee_id')
                                        ->select('car_requisitions.*','employee.full_name','employee.designation_name','employee.personal_Phone','employee.photo','employee.department_name')
                                        ->where('car_requisitions.departure_date','=',date('Y-m-d'))
                                        ->whereNotIn('car_requisitions.status',[2,6,7])
                                        ->get()
                                        ->map(function ($car_requisitions_today) {
                                            $car_registration_info = DB::table('car_registration_info')
                                            ->leftJoin('employee', 'employee.employee_id', '=', 'car_registration_info.employee_id')
                                            ->select('employee.full_name','employee.personal_Phone','employee.photo')
                                            ->where('car_registration_info.id',$car_requisitions_today->car_id)            
                                            ->first();
                                            $car_requisitions_today->driver_info = $car_registration_info ?? (object)[];
                                            return $car_requisitions_today;
                                        })
                                        ->toArray();
            $car_requisitions_tomorrow = DB::table('car_requisitions')
                                        ->leftJoin('employee', 'employee.employee_id', '=', 'car_requisitions.employee_id')
                                        ->select('car_requisitions.*','employee.full_name','employee.designation_name','employee.personal_Phone','employee.photo','employee.department_name')
                                        ->where('car_requisitions.departure_date','>=',date("Y-m-d", strtotime("+1 day")))
                                        ->whereNotIn('car_requisitions.status',[2,6,7])
                                        ->get()
                                        ->map(function ($car_requisitions_tomorrow) {
                                            $car_registration_info = DB::table('car_registration_info')
                                            ->leftJoin('employee', 'employee.employee_id', '=', 'car_registration_info.employee_id')
                                            ->select('employee.full_name','employee.personal_Phone','employee.photo')
                                            ->where('car_registration_info.id',$car_requisitions_tomorrow->car_id)            
                                            ->first();
                                            $car_requisitions_tomorrow->driver_info = $car_registration_info ?? (object)[];
                                            return $car_requisitions_tomorrow;
                                        })
                                        ->toArray();
            $data = array(
                'today'=> $car_requisitions_today,
                'tomorrow'=> $car_requisitions_tomorrow,
            );
            return response()->json(['status' => 1, 'message' => 'Car requisition list.', 'data'=>$data]);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }

     function car_requisition_list_self() {
        try {
            $user = $this->guard()->user();	
            $car_requisitions = DB::table('car_requisitions')
                                        ->leftJoin('employee', 'employee.employee_id', '=', 'car_requisitions.employee_id')
                                        ->select('car_requisitions.*','employee.full_name','employee.designation_name','employee.personal_Phone','employee.photo','employee.department_name')
                                        ->where('car_requisitions.employee_id','=',$user->employee_id)
                                        ->get()
                                        ->map(function ($car_requisitions_today) {
                                            $car_registration_info = DB::table('car_registration_info')
                                            ->leftJoin('employee', 'employee.employee_id', '=', 'car_registration_info.employee_id')
                                            ->select('employee.full_name','employee.personal_Phone','employee.photo')
                                            ->where('car_registration_info.id',$car_requisitions_today->car_id)            
                                            ->first();
                                            $car_requisitions_today->driver_info = $car_registration_info ?? (object)[];
                                            return $car_requisitions_today;
                                        })
                                        ->toArray();
            return response()->json(['status' => 1, 'message' => 'Persons Car Requisition List.', 'data'=>$car_requisitions]);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }

     function car_requisition_cancel(Request $request) {
        try {
            $user = $this->guard()->user();	
            $car_requisitions = DB::table('car_requisitions')->where('id',$request->requisition_id)->first();

            $validator = Validator::make($request->all(), [
                'status' => 'required|digits:7'
            ]);
            $data = array(
                'status' =>$request->status
            );

            $carRequisition = DB::table('car_requisitions')->where('id',$request->requisition_id)->update($data);
            if (!empty($car_requisitions->car_id) && $carRequisition) {
                $datum = array(
                    'booked_status' => 0
                );
                $carRequisition = DB::table('car_registration_info')->where('id',$car_requisitions->car_id)->update($datum);
            }

            if ($request->status == 7) {
                $message =  'Car Requisition Cancel Successful!';
            }
            return response()->json(['status' => 1, 'message' => $message]);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }

     function car_requisition_approval_boss(Request $request) {
        try {
            $user = $this->guard()->user();	
            $car_requisitions = DB::table('car_requisitions')->where('id',$request->requisition_id)->first();

            $validator = Validator::make($request->all(), [
                'status' => 'required'
            ]);
            $data = array(
                'status' =>$request->status,
                'approve_by' => $user->employee_id
            );

            $carRequisition = DB::table('car_requisitions')->where('id',$request->requisition_id)->update($data);
            if ($request->status == 1) {
                FirebaseMessage::send($car_requisitions->employee_id,'Car Requisition Approve.', 'Car Approved By Boss.');
                $message =  'Approved Successfully!';
            }elseif ($request->status == 2){
                FirebaseMessage::send($car_requisitions->employee_id,'Car Requisition Reject.', 'Car Rejected By Boss.');
                $message =  'Rejected Successfully!';
            }
            return response()->json(['status' => 1, 'message' => $message]);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }

     function car_requisition_approval_hr(Request $request) {
        try {
            $user = $this->guard()->user();	
            $car_requisitions = DB::table('car_requisitions')->where('id',$request->requisition_id)->first();

            $validator = Validator::make($request->all(), [
                'status' => 'required'
            ]);
            $data = array(
                'car_id' => $request->car_id ?? '',
                'status' =>$request->status,
                'approver_note' => $request->note ?? '',
                'approve_by' => $user->employee_id
            );

            $datum = array(
                'booked_status' => 1
            );

            $carRequisition = DB::table('car_requisitions')->where('id',$request->requisition_id)->update($data);
            if ($request->status == 3) {
                $car_registration_info = DB::table('car_registration_info')->where('id',$request->car_id)->update($datum);
                FirebaseMessage::send($car_requisitions->employee_id,'Car Requisition Approve.', 'Car Approve By HR.');
                $message =  'Approved Successfully!';
            }elseif ($request->status == 6){
                $notify_employee = ['00002', $car_requisitions->employee_id];
                foreach ($notify_employee as $key => $emp) {
                    FirebaseMessage::send($emp,'Car Requisition Reject.', $request->note);
                }
                $message =  'Rejected Successfully!';
            }
            return response()->json(['status' => 1, 'message' => $message]);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }
    // public function car_requisition_acknowledge(Request $request) {
    //     try {
    //         $user = $this->guard()->user();	
    //         $validator = Validator::make($request->all(), [
    //             'car_id' => 'required',
    //             'status' => 'required'
    //         ]);
    //         $data = array(
    //             'car_id' => $request->car_id,
    //             'status' => $request->status
    //         );

    //         $datum = array(
    //             'booked_status' => 1
    //         );

    //         $car_requisitions = DB::table('car_requisitions')->where('id',$request->requisition_id)->update($data);
    //         $car_registration_info = DB::table('car_registration_info')->where('id',$request->car_id)->update($datum);

    //         return response()->json(['status' => 1, 'message' => 'Successfully Done!']);
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 0, 'message' => $e->getMessage()]);
    //     }
    // }

     function car_start(Request $request) {
        try {
            $user = $this->guard()->user();	// Validate the request data
			$_car_requisitions = DB::table('car_requisitions')->where('id', $request->requisition_id)->get()->first();
            $car_req = DB::table('car_registration_info')->where('id', $_car_requisitions->car_id)->get()->first();
			
			
			// $car_req = DB::table('car_requisitions')
                        // ->leftJoin('car_registration_info', 'car_registration_info.id', '=', 'car_requisitions.car_id')
                        // ->select('car_requisitions.car_id','car_registration_info.car_mileage','car_registration_info.car_current_mileage as car_current_mileage')
                        // ->where('car_requisitions.id', $request->requisition_id)
                        // ->where('car_requisitions.status', 1)
                        // ->get()
                        // ->first();

			$_current_milage = (float)($car_req->car_current_mileage);
			$validator = Validator::make($request->all(), [
                'start_image' 		=> 'required',
                'start_mileage' 	=> 'required|numeric|gte:' . $_current_milage,
                'requisition_id' 	=> 'required',
                'status' 			=> 'required'
            ]);
            
            if ($validator->fails()) {
                // Return validation errors in JSON format
                return response()->json(['status' => 0, 'message' => $validator->errors()], 422);
            }

            $attachment = file_upload_with_directory('start_image', 'car_requisition/');
            $data = array(
                'start_image' 		=> $attachment,
                'start_mileage' 	=> $request->start_mileage,
                'missing_mileage' 	=> $request->start_mileage - $_current_milage,
                'status' 			=> $request->status
            );
            $car_requisitions = DB::table('car_requisitions')->where('id',$request->requisition_id)->update($data);
            return response()->json(['status' => 1, 'message' => 'Successfully Done!']);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }
     function car_stop(Request $request) {
        try {
            $user = $this->guard()->user();	
			$_car_requisitions = DB::table('car_requisitions')->where('id', $request->requisition_id)->get()->first();
            $car_req = DB::table('car_registration_info')->where('id', $_car_requisitions->car_id)->get()->first();
			
			
            // $car_req = DB::table('car_requisitions')
                        // ->leftJoin('car_registration_info', 'car_registration_info.id', '=', 'car_requisitions.car_id')
                        // ->select('car_requisitions.car_id','car_requisitions.start_mileage','car_registration_info.car_mileage','car_registration_info.car_current_mileage')
                        // ->where('car_requisitions.id',$request->requisition_id)
                        // ->get()
                        // ->first();
                        
            // Validate the request data
			$_current_milage = (float)($car_req->car_current_mileage);
            $validator = Validator::make($request->all(), [
                'end_image' 		=> 'required',
                'end_mileage' 		=> 'required|numeric|gte:' . $_current_milage,
                'requisition_id' 	=> 'required',
                'status' 			=> 'required'
            ]);
            
            if ($validator->fails()) {
                // Return validation errors in JSON format
                return response()->json(['status' => 0, 'message' => $validator->errors()], 422);
            }

            $attachment = file_upload_with_directory('end_image', 'car_requisition/');
            $data = array(
                'end_image' 		=>$attachment,
                'end_mileage' 		=>$request->end_mileage,
                'used_mileage' 		=>$_car_requisitions->start_mileage - $request->end_mileage,
                'status' 			=>$request->status
            );
            $datum = array(
                'booked_status' => 0,
                'car_current_mileage' =>$request->end_mileage,
            );
            $car_registration_info = DB::table('car_registration_info')->where('id', $_car_requisitions->car_id)->update($datum);
            $car_requisitions = DB::table('car_requisitions')->where('id',$request->requisition_id)->update($data);
            return response()->json(['status' => 1, 'message' => 'Successfully Done!']);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }

     function vehicle_type() {
        try {
            $ta_da_vhicle_list = DB::table('ta_da_vhicle_list')->where('status',1)->orderBy('serial', 'asc')->get();
            return response()->json(['status' => 1, 'message' => 'Successfully Done!','data'=>$ta_da_vhicle_list]);
        } catch (\Exception $e) {
            return response()->json(['status' => 0, 'message' => $e->getMessage()]);
        }
    }